# Installation
> `npm install --save @types/babel__generator`

# Summary
This package contains type definitions for @babel/generator (https://github.com/babel/babel/tree/master/packages/babel-generator).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/babel__generator.

### Additional Details
 * Last updated: Thu, 03 Apr 2025 16:02:41 GMT
 * Dependencies: [@babel/types](https://npmjs.com/package/@babel/types)

# Credits
These definitions were written by [Troy Gerwien](https://github.com/yortus), [Melvin Groenhoff](https://github.com/mgroenhoff), [Cameron Yan](https://github.com/khell), and [Lyanbin](https://github.com/Lyanbin).
