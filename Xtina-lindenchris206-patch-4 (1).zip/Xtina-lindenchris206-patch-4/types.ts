export interface ChatMessage {
  id: string;
  role: 'user' | 'ai' | 'system';
  text: string;
  ts: string;
  imageUrl?: string;
  councilMessages?: CouncilMessage[];
}

export interface CouncilMessage {
  agentName: string;
  response: string;
}

export interface KnowledgeBundle {
  name: string;
  type: 'file' | 'text';
  path?: string; // path on server for files
}

export interface Agent {
  id?: string;
  name: string;
  description: string;
  primarySpecialty: string;
  secondarySpecialties: string[];
  knowledgeBundles: KnowledgeBundle[];
  currentEngine?: string;
  engineOptions?: string[];
  selfImprove?: boolean;
  help?: string[];
  enabled?: boolean;
}

export interface Task {
    id: string;
    title: string;
    status: 'queued' | 'running' | 'done' | 'failed';
    assignedAgent?: string;
    completedAt?: string;
    prompt?: string;
    output?: {
      type: 'text' | 'image' | 'council';
      content: string;
      councilMessages?: CouncilMessage[];
    }
}

export interface Conversation {
  id: string;
  title: string;
  messages: ChatMessage[];
}