
import React, { useState, useEffect } from 'react';
import type { APIKey } from '../types';
import { KeyIcon, TrashIcon, XIcon, SaveIcon } from './icons';

const STORAGE_KEY = 'xtina_api_keys_v1';

function loadKeys(): APIKey[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    return JSON.parse(raw) as APIKey[];
  } catch (e) { return []; }
}

function saveKeys(keys: APIKey[]) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(keys));
}

export default function APIKeyManager(){
  const [keys, setKeys] = useState<APIKey[]>([]);
  const [editing, setEditing] = useState<APIKey | null>(null);
  const [showModal, setShowModal] = useState(false);

  useEffect(()=> { setKeys(loadKeys()); }, []);

  const addKey = (k: APIKey) => {
    const next = [...keys, k];
    setKeys(next); saveKeys(next);
  };
  const updateKey = (k: APIKey) => {
    const next = keys.map(x=> x.id===k.id ? k : x);
    setKeys(next); saveKeys(next);
  };
  const deleteKey = (id:string) => {
    const next = keys.filter(x=> x.id!==id);
    setKeys(next); saveKeys(next);
  };

  return (<div style={{padding:12}}>
    <h2>API Key Manager</h2>
    <p>Local demo: keys stored in browser localStorage. For production, back-end encrypted store required.</p>
    <div style={{display:'flex',gap:10}}>
      <div style={{minWidth:320}}>
        {keys.map(k => (
          <div key={k.id} style={{padding:8,border:'1px solid #ddd',marginBottom:6,display:'flex',justifyContent:'space-between',alignItems:'center'}}>
            <div>
              <strong>{k.service}</strong>
              <div style={{fontSize:12,color:'#666'}}>{k.key ? '••••••••' : <em>No key</em>}</div>
            </div>
            <div style={{display:'flex',gap:8}}>
              <button onClick={()=>{ setEditing(k); setShowModal(true); }} title="Edit"><KeyIcon /></button>
              <button onClick={()=>deleteKey(k.id)} title="Delete"><TrashIcon /></button>
            </div>
          </div>
        ))}
        <button onClick={()=>{ setEditing({ id: crypto.randomUUID(), service:'', key:'' }); setShowModal(true); }} style={{marginTop:8}}>Add API Key</button>
      </div>
      <div style={{flex:1}}>
        <h3>Rotation & Logs (stub)</h3>
        <p>This demo shows a simplified key manager. Rotation, hashing, logging and server-side storage are available in the full system.</p>
      </div>
    </div>

    {showModal && editing && (
      <div style={{position:'fixed',inset:0,background:'rgba(0,0,0,0.5)',display:'flex',alignItems:'center',justifyContent:'center'}}>
        <div style={{background:'#fff',padding:16,width:460,borderRadius:8}}>
          <div style={{display:'flex',justifyContent:'space-between',alignItems:'center'}}>
            <h4>{editing.service ? 'Edit' : 'Add'} API Key</h4>
            <button onClick={()=>setShowModal(false)}><XIcon /></button>
          </div>
          <div style={{marginTop:8}}>
            <label>Service</label>
            <input value={editing.service} onChange={(e)=>setEditing({...editing!, service:e.target.value})} style={{width:'100%'}} />
          </div>
          <div style={{marginTop:8}}>
            <label>Key</label>
            <input value={editing.key} onChange={(e)=>setEditing({...editing!, key:e.target.value})} style={{width:'100%'}} />
          </div>
          <div style={{marginTop:12,display:'flex',gap:8,justifyContent:'flex-end'}}>
            <button onClick={()=>{ setShowModal(false); }}>Cancel</button>
            <button onClick={()=>{ if (editing){ if (keys.some(k=>k.id===editing.id)) updateKey(editing); else addKey(editing); setShowModal(false); } }}><SaveIcon /></button>
          </div>
        </div>
      </div>
    )}
  </div>);
}
