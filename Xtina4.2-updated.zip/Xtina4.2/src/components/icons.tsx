
import React from 'react';

const Icon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="w-5 h-5" {...props}>
    {props.children}
  </svg>
);

export const KeyIcon: React.FC<React.SVGProps<SVGSVGElement>> = (p) => <Icon {...p}><path d="M3 11a4 4 0 1 1 4 4H3v4h4" /><circle cx="9" cy="7" r="4" /></Icon>;
export const TrashIcon: React.FC<React.SVGProps<SVGSVGElement>> = (p) => <Icon {...p}><polyline points="3 6 5 6 21 6" /><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6" /><path d="M10 11v6" /><path d="M14 11v6" /></Icon>;
export const XIcon: React.FC<React.SVGProps<SVGSVGElement>> = (p) => <Icon {...p}><line x1="18" y1="6" x2="6" y2="18" /><line x1="6" y1="6" x2="18" y2="18" /></Icon>;
export const SaveIcon: React.FC<React.SVGProps<SVGSVGElement>> = (p) => <Icon {...p}><path d="M19 21H5a2 2 0 0 1-2-2V7a2 2 0 0 1 2-2h11l5 5v9a2 2 0 0 1-2 2z" /><polyline points="17 21 17 13 7 13 7 21" /></Icon>;
