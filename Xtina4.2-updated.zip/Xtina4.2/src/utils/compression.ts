// Lightweight stubs for compression utilities. Implement with a backend for production.
export async function compressFiles(filePaths:string[]):Promise<string>{
  // returns path to archive
  console.warn('compressFiles: stub called. Implement server-side for real compression.');
  return '/tmp/archive.zip';
}

export async function extractArchive(archivePath:string, dest:string):Promise<boolean>{
  console.warn('extractArchive: stub called. Implement server-side for real extraction.');
  return true;
}
