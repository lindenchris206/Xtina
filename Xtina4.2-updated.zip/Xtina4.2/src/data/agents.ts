import type { AgenticAI } from '../types';

// 22 sample Agentic AIs with primary + 2-4 secondary specialties
const agents: AgenticAI[] = [
  { id: 'a1', name: 'Lead', primary: 'Project Management', secondary: ['Planning','Coordination','Risk'] },
  { id: 'a2', name: 'CodeDoc', primary: 'Documentation', secondary: ['API','Tutorials','Adoption'] },
  { id: 'a3', name: 'FrontendPro', primary: 'Frontend', secondary: ['React','CSS','Accessibility'] },
  { id: 'a4', name: 'BackendGuru', primary: 'Backend', secondary: ['Node','Databases','APIs'] },
  { id: 'a5', name: 'SecAnalyst', primary: 'Security', secondary: ['Threat Modeling','Hardening','Forensics'] },
  { id: 'a6', name: 'LLMTrainer', primary: 'ML Ops', secondary: ['Fine-tuning','Prompting','Evaluation'] },
  { id: 'a7', name: 'LegalAid', primary: 'Legal (General)', secondary: ['Contracts','Privacy','Compliance'] },
  { id: 'a8', name: 'RealEstate', primary: 'Real Estate Law', secondary: ['Trusts','Leases','Property'] },
  { id: 'a9', name: 'DataDetective', primary: 'Data Engineering', secondary: ['ETL','Quality','Pipelines'] },
  { id: 'a10', name: 'UXSmith', primary: 'UX Research', secondary: ['Usability','Prototyping','Testing'] },
  { id: 'a11', name: 'EcomOps', primary: 'Ecommerce', secondary: ['Payments','Catalog','Checkout'] },
  { id: 'a12', name: 'Forensics', primary: 'Investigations', secondary: ['Finding People','OSINT','Records'] },
  { id: 'a13', name: 'Pythonista', primary: 'Python', secondary: ['Scripting','Web','Data Science'] },
  { id: 'a14', name: 'TypeScriptAce', primary: 'TypeScript', secondary: ['Types','Build','Tooling'] },
  { id: 'a15', name: 'JavaMaster', primary: 'Java', secondary: ['Backend','Concurrency','JVM'] },
  { id: 'a16', name: 'DesignOps', primary: 'Design', secondary: ['System Design','Patterns','Docs'] },
  { id: 'a17', name: 'DevOps', primary: 'DevOps', secondary: ['CI/CD','Infra','Containers'] },
  { id: 'a18', name: 'PrivacyPro', primary: 'Privacy', secondary: ['GDPR','DataFlows','Policy'] },
  { id: 'a19', name: 'Contracts', primary: 'Paralegal', secondary: ['Forms','Filing','Templates'] },
  { id: 'a20', name: 'DBA', primary: 'Databases', secondary: ['SQL','NoSQL','Performance'] },
  { id: 'a21', name: 'Marketing', primary: 'Marketing', secondary: ['SEO','Ads','Copy'] },
  { id: 'a22', name: 'AIAlign', primary: 'AI Safety', secondary: ['RLHF','Audit','Governance'] },
];

export default agents;
