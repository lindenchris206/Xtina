import type { HelperAgent } from '../types';
// 70 helper agents stubbed into categories
const categories = [
  'File Ops','Text Ops','Image Ops','Data Ops','Web Ops','Security Ops','Utilities'
];

const helpers: HelperAgent[] = [];
for(let i=1;i<=70;i++){
  const cat = categories[i % categories.length];
  helpers.push({ id: 'h'+i, name: `${cat} Helper ${i}`, category: cat, description: `Performs ${cat} task #${i}` });
}

export default helpers;
