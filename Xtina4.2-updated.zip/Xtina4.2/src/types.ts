// Shared lightweight types for the Knowledge Base
export type Specialty = {
  id: string;
  name: string;
  level?: number; // proficiency 0-100
};

export type AgenticAI = {
  id: string;
  name: string;
  primary: string;
  secondary: string[];
  description?: string;
  expertiseLevel?: number;
};

export type HelperAgent = {
  id: string;
  name: string;
  category: string;
  description?: string;
};

export type KnowledgeBundle = {
  id: string;
  title: string;
  description?: string;
  files: string[]; // paths or references
  sizeBytes?: number;
};


export interface APIKey { id: string; service: string; key: string; }
