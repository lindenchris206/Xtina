import React from 'react';
import type { KnowledgeBundle } from '../types';

const sample: KnowledgeBundle[] = [
  { id:'k1', title:'Frontend Basics', description:'HTML/CSS/JS starter pack', files:['frontend-basics.pdf'], sizeBytes:1024*120 },
  { id:'k2', title:'Legal Forms Kit', description:'Common templates', files:['lease.docx','nda.docx'], sizeBytes:1024*240 }
];

export default function KnowledgeBundles(){
  const [bundles] = React.useState<KnowledgeBundle[]>(sample);
  return (<div style={{padding:20}}>
    <h1>Knowledge Bundles</h1>
    <p>Upload, tag, compress, and assign bundles to Agentic AI.</p>
    <div>
      {bundles.map(b=> (
        <div key={b.id} style={{padding:10,border:'1px solid #ddd',marginBottom:8}}>
          <strong>{b.title}</strong> — {b.description}<div style={{fontSize:12}}>{b.files.join(', ')} • {(b.sizeBytes||0)/1024} KB</div>
        </div>
      ))}
    </div>
  </div>);
}
