import React from 'react';
import agents from '../data/agents';
import helpers from '../data/helpers';
import type { AgenticAI } from '../types';

export default function KnowledgeBase(){ 
  const [selected, setSelected] = React.useState<AgenticAI | null>(null);
  return ( <div style={{padding:20}}>
    <h1>Xtina Knowledge Base — Agentic Crew</h1>
    <p>22 Agentic AI crew members. Select one to view specialties and linked bundles.</p>
    <div style={{display:'flex',gap:20}}>
      <div style={{minWidth:300}}>
        {agents.map(a => (
          <div key={a.id} style={{padding:8,border:'1px solid #ddd',marginBottom:6,cursor:'pointer'}} onClick={()=>setSelected(a)}>
            <strong>{a.name}</strong><div style={{fontSize:12,color:'#666'}}>{a.primary} — {a.secondary.join(', ')}</div>
          </div>
        ))}
      </div>
      <div style={{flex:1}}>
        {selected ? (
          <div>
            <h2>{selected.name}</h2>
            <p><strong>Primary:</strong> {selected.primary}</p>
            <p><strong>Secondary:</strong> {selected.secondary.join(', ')}</p>
            <p>Notes: This view can show linked knowledge bundles, training progress, and actions to "assign bundle" or "request research".</p>
          </div>
        ) : <div><em>Select an agent to inspect</em></div>}
      </div>
    </div>
    <hr/>
    <h3>Helper Agents (sample)</h3>
    <div style={{display:'grid',gridTemplateColumns:'repeat(3,1fr)',gap:6,maxWidth:900}}>
      {helpers.slice(0,12).map(h=> <div key={h.id} style={{padding:8,border:'1px solid #eee'}}>{h.name}<div style={{fontSize:12,color:'#666'}}>{h.category}</div></div>)}
    </div>
  </div>);
}
