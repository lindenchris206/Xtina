import React from 'react';
import { createRoot } from 'react-dom/client';
import KnowledgeBase from './pages/KnowledgeBase';
import KnowledgeBundles from './pages/KnowledgeBundles';
import APIKeyManager from './components/APIKeyManager';

function App(){
  return <div>
    <nav style={{padding:10,background:'#f6f6f8'}}>
              <a href='#apikeys'>API Keys</a> | 
      <a href='#kb'>Knowledge Base</a> | <a href='#kbundles'>Knowledge Bundles</a>
    </nav>
    <div id='kb' style={{padding:20}}><KnowledgeBase/></div>
    <div id='kbundles' style={{padding:20}}><KnowledgeBundles/></div>
<div id='apikeys' style={{padding:20}}><APIKeyManager/></div>
  </div>;
}

const el = document.createElement('div');
document.body.appendChild(el);
createRoot(el).render(<App/>);
