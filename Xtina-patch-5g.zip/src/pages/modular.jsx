
import React from 'react'

const KEY='xtina:modular:layout'
const SILVER = 'bg-[linear-gradient(145deg,_#dfe3ea_0%,_#c9ced6_38%,_#b8bec8_60%,_#e9edf2_100%)]'
const GLOW_BLUE = 'shadow-[0_0_22px_4px_rgba(56,189,248,0.35),_0_0_60px_12px_rgba(56,189,248,0.18)]'
const GLOW_PINK = 'shadow-[0_0_16px_3px_rgba(244,114,182,0.35),_0_0_48px_10px_rgba(192,132,252,0.18)]'
const HEX = '[clip-path:polygon(25%_0%,_75%_0%,_100%_50%,_75%_100%,_25%_100%,_0%_50%)]'

function useSize(){
  const [s,setS]=React.useState({w:window.innerWidth,h:window.innerHeight})
  React.useEffect(()=>{
    const on=()=>setS({w:window.innerWidth,h:window.innerHeight})
    window.addEventListener('resize',on); return()=>window.removeEventListener('resize',on)
  },[])
  return s
}
function ring(count, center, r){
  const out=[]; const start=-Math.PI/2
  for(let i=0;i<count;i++){ const t=start + i*(2*Math.PI/count); out.push({x:center.x + r*Math.cos(t), y:center.y + r*Math.sin(t)}) }
  return out
}
export default function ModularPage(){
  const {w,h}=useSize(); const center={x:w/2, y:h/2 - 40}
  const [nodes,setNodes]=React.useState(()=>{ try{ return JSON.parse(localStorage.getItem(KEY)) || [] }catch{ return [] } })
  React.useEffect(()=>{ localStorage.setItem(KEY, JSON.stringify(nodes)) },[nodes])
  const baseSize=260, childSize=150

  React.useEffect(()=>{
    if(nodes.length>4){
      const coords=ring(nodes.length, center, Math.min(w,h)/3.0)
      setNodes(prev=> prev.map((n,i)=>({...n,x:coords[i].x, y:coords[i].y, hex:true})))
    } else { setNodes(prev=> prev.map(n=>({...n, hex:false}))) }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  },[nodes.length, w, h])

  const addNode = (title)=>{
    const angle = (nodes.length%4)*Math.PI/2; const r = baseSize*0.9 + 40
    const pos = { x: center.x + r*Math.cos(angle), y: center.y + r*Math.sin(angle) }
    setNodes(ns=> [...ns, { id: Date.now().toString(36), title, x: pos.x, y: pos.y }])
  }
  const removeNode = (id)=> setNodes(ns=> ns.filter(n=> n.id!==id))
  const drag = React.useRef({ id:null, dx:0, dy:0 })
  const onDown=(e,id)=>{ const n = nodes.find(n=>n.id===id); if(!n) return
    drag.current={ id, dx:e.clientX - n.x, dy:e.clientY - n.y }
    window.addEventListener('mousemove', onMove); window.addEventListener('mouseup', onUp)
  }
  const onMove=(e)=>{ const d=drag.current; if(!d.id) return
    setNodes(ns=> ns.map(n=> n.id===d.id ? {...n, x:e.clientX - d.dx, y:e.clientY - d.dy } : n))
  }
  const onUp=()=>{ drag.current={id:null,dx:0,dy:0}; window.removeEventListener('mousemove', onMove); window.removeEventListener('mouseup', onUp) }
  const lines = nodes.map(n=>({ x1:center.x, y1:center.y, x2:n.x, y2:n.y }))
  const palette = ['Research','Build','Review','Deploy','Docs','Analyze','Design','Finance']

  return (
    <div className=\"h-[calc(100vh-64px)] relative overflow-hidden bg-gradient-to-b from-zinc-900 via-black to-zinc-950 text-white\">
      <div className=\"absolute left-2 top-2 bottom-2 w-48 rounded-2xl border border-zinc-700/60 bg-zinc-900/60 p-3 backdrop-blur\">
        <div className=\"text-sm opacity-80\">Blocks</div>
        <div className=\"mt-2 grid grid-cols-2 gap-2\">
          {palette.map(p=> (<button key={p} className={\`text-xs \${SILVER} \${GLOW_PINK} rounded-xl px-2 py-2 text-zinc-800 hover:opacity-90\`} onClick={()=> addNode(p)}>{p}</button>))}
        </div>
        <div className=\"mt-4 text-xs opacity-60\">Tip: drag blocks; if you add more than four, layout becomes a ring with hex shapes.</div>
      </div>
      <svg className=\"absolute inset-0 pointer-events-none\" width={w} height={h}>
        <defs><linearGradient id=\"grad\" x1=\"0\" y1=\"0\" x2=\"1\" y2=\"1\"><stop offset=\"0%\" stopColor=\"#38bdf8\" stopOpacity=\"0.6\"/><stop offset=\"100%\" stopColor=\"#f472b6\" stopOpacity=\"0.6\"/></linearGradient></defs>
        {lines.map((l,i)=> (<line key={i} x1={l.x1} y1={l.y1} x2={l.x2} y2={l.y2} stroke=\"url(#grad)\" strokeWidth=\"2\" />))}
      </svg>
      <div className={\`absolute \${SILVER} \${GLOW_BLUE} rounded-3xl text-zinc-800\`} style={{ width: 260, height: 260, left: center.x - 130, top: center.y - 130 }}>
        <div className=\"h-full w-full flex flex-col items-center justify-center select-none\">
          <div className=\"text-xl font-semibold\">BASE</div>
          <div className=\"text-xs opacity-70\">Silver core • Blue glow</div>
          <div className=\"mt-2 text-[10px] opacity-60\">{nodes.length} linked</div>
        </div>
      </div>
      {nodes.map(n=> (
        <div key={n.id} className={\`absolute \${SILVER} \${GLOW_PINK} \${n.hex?HEX:''} rounded-2xl text-zinc-800 cursor-move\`} style={{ width: 150, height: 150, left: n.x - 75, top: n.y - 75 }} onMouseDown={(e)=> onDown(e, n.id)}>
          <div className=\"h-full w-full flex flex-col items-center justify-center select-none\">
            <div className=\"font-semibold\">{n.title}</div>
            <div className=\"text-[11px] opacity-60\">drag to position</div>
            <button className=\"mt-2 text-[11px] underline\" onClick={(e)=>{ e.stopPropagation(); removeNode(n.id) }}>remove</button>
          </div>
        </div>
      ))}
      <div className=\"absolute right-4 top-4 flex gap-2\">
        <button className=\"px-3 py-2 rounded-lg border border-zinc-700/60 bg-black/50\" onClick={()=> setNodes([])}>Clear</button>
        <button className=\"px-3 py-2 rounded-lg border border-zinc-700/60 bg-black/50\" onClick={()=> localStorage.setItem(KEY, JSON.stringify(nodes))}>Save</button>
      </div>
    </div>
  )
}
