import { cloneDeep } from '../util/cloneDeep'
import defaultFullConfig from '../../stubs/config.full'

export default cloneDeep(defaultFullConfig.theme)
