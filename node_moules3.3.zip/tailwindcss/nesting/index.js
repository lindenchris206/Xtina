let nesting = require('../lib/postcss-plugins/nesting')
module.exports = (nesting.__esModule ? nesting : { default: nesting }).default
