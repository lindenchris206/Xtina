import {
  require_react_dom
} from "./chunk-T4EUF24Z.js";
import "./chunk-VK7NP5LZ.js";
import "./chunk-VUNV25KB.js";
export default require_react_dom();
