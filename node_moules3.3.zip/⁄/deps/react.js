import {
  require_react
} from "./chunk-VK7NP5LZ.js";
import "./chunk-VUNV25KB.js";
export default require_react();
