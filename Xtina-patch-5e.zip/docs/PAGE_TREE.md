# Xtina — Page & Feature Tree (Patch 5)
_Generated: 2025-10-22 19:32:19_

- **Home / Dashboard**
  - Quick Actions
  - Recent Bundles
  - Active Agents (Renee + 2 others)
- **Studio**
  - Web Studio (project workspace, file tree, preview, deploy)
  - Data Studio (bundles, converters, compress/decompress)
  - Agent Studio (configure agents, specialties, knowledge sources)
- **Agents**
  - Renee (Lead / Orchestrator)
  - Agent A, Agent B (switchable engines)
  - Floating Widget (global quick-assist)
- **Connections**
  - API Key Manager (rotation, vault, health)
  - Integrations: GitHub, GitGuardian, Keystatic, AB Tasty, Zendesk, etc.
- **Knowledge**
  - Bundles Library
  - Drop Zone (drag & drop files/URLs)
  - Web Scrape Tasks (scheduled, on-demand)
- **Settings**
  - Accessibility: Text Size, Zoom, Reduced Motion
  - Audio: Voice default **muted**, toggle to enable
  - Privacy: Data collection, local-only mode
- **Help**
  - Manual, Shortcuts, Troubleshooting

## UI Buttons / Navigation Elements
- Global Topbar: Home, Studio, Agents, Knowledge, Connections, Settings, Help
- Floating Widget: open/close, pin, screenshot-to-context, quick actions
- Agent Cards: Set Primary/Secondary Specialties; Add Knowledge Bundle
- Connections: Add Key, Rotate Now, Audit, Health Check
- Accessibility: A-/A+ (text size), Zoom -, 100%, Zoom +