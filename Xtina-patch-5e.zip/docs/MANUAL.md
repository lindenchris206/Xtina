# Xtina Manual (Patch 5)

## 1. Overview
Xtina is a modular, multi-agent workspace. Renee acts as the team lead/orchestrator.
Agents can have primary and secondary specialties. Knowledge comes from user-provided bundles and optional scraping tasks.

## 2. Accessibility
- Text-size toggle in the header (A-/A+)
- Zoom controls in Settings (Zoom -, Reset, Zoom +)
- Voice is **muted by default**; enable in Settings if needed.

## 3. Floating Widget
- Click the bubble to open.
- Drag to dock left/right; pin to keep on top.
- Drop files/links to create ad-hoc knowledge bundles.

## 4. Knowledge Bundles
- Use **Knowledge → Drop Zone** to add files or URLs.
- Bundles include a manifest describing purpose, tags, and preferred agent specialties.
- Example manifest added at `src/agents/knowledge/sample-bundle.manifest.json`.

## 5. Connections & Key Rotation
- Add API keys in **Connections → API Key Manager**.
- Keys are encrypted at rest. Rotation tasks can be scheduled.
- Audit logs live at `data/logs/key-ops.log` (create the folder if it doesn't exist).

## 6. Engines & Agents
- Each agent can target a different engine (configurable).
- Renee delegates tasks to other agents based on specialties and bundle tags.

## 7. Web Studio
- Project-oriented workspace. File tree, live preview, and (optional) deploy.
- Connects with the browser module for scraping and bundle creation.

## 8. Troubleshooting
- If the app fails to start, check `.env` for required keys.
- Ensure Node version >= 18 if using the web UI.
- For rotation errors, check `data/logs/key-ops.log`.

_This draft ships with Patch 5 and will be iterated._


## Patch 5c — Agents, Assistants, Knowledge

- **100 Specialties** defined at `src/agents/specialties.ts` (editable).
- Each agent now has **2–3 assistants** (`assistantIds`) for skill-stacking.
- **Secondary specialties** are editable per-agent with a click UI.
- **Knowledge Bases page** (`/knowledge`) lets users create, rename, delete bundles; shown in an **A→Z carousel**.
- Selections persist in `localStorage` for now (swap to SQLite when ready).

_Generated: 2025-10-22 19:55:58_



## Patch 5d — Deliberation Room (Collaborative Debate)

- New **Deliberation Room** at `/debate` where agents **discuss, critique, revise, vote**, and produce a **blended answer**.
- Debate protocol stages: *brief → proposals → cross-exam → revision → vote → synthesis*.
- Weighted **Blend** favors evidence & correctness; rationale explains the choice.
- Works offline for demo; swap stub generators with live model calls when engines are connected.

_Generated: 2025-10-22 19:58:45_



## Patch 5e — File Explorer & All-Formats Handling

- New **File Explorer** at `/files` with: browse, filter, breadcrumbs, create, rename, copy, move, delete.
- Drag & drop **upload**, ZIP/UNZIP, and inline **preview** for text, images, audio, and video.
- Secure **FS API** server with a configurable root (`XTINA_ROOT`) and path-safety checks.
- Binary-safe **download/read** route and simple text editor that saves on blur.

_Generated: 2025-10-22 20:10:26_
