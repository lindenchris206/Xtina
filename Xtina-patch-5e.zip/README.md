# Xtina

## Patch 5 Additions
- FloatingWidget (src/components/FloatingWidget.jsx)
- AccessibilityControls (src/components/AccessibilityControls.jsx)
- AgentRegistry with specialties (src/agents/AgentRegistry.ts)
- Knowledge bundles scaffold (src/agents/knowledge/)
- Key Manager skeleton (src/config/keyManager/RotatingKeyManager.ts)
- Docs: PAGE_TREE.md, MANUAL.md

> Voice is muted by default; enable via Settings.


**New:** Deliberation Room `/debate` — multi-agent debate with synthesis.


### File Explorer Server

Start the FS API (from repo root):

```bash
cp package.server.json package.json
npm i
npm run dev   # starts on :8788
# Set a workspace root:
XTINA_ROOT=/absolute/path/to/your/workspace npm run dev
```

The web app expects the API at `/api/fs/*`. If your UI runs on a different port, add a proxy in your dev server (Vite/Next) or reverse-proxy via nginx.
