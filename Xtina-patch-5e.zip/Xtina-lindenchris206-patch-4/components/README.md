Christina Mini — Integrations-enabled scaffold

Start server:
  cd christina-mini
  npm install
  npm run start:server

Open: http://localhost:3000/integrations

Default uploads folder: ./uploads

Credentials stored in server/data/credentials.enc.json (encrypted).
Set MASTER_KEY in .env for production.

See scripts/* for example flows.
