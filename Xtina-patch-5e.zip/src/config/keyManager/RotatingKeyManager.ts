// RotatingKeyManager.ts
// Skeleton for key storage + rotation schedule (implementation depends on runtime).

export interface StoredKey {
  service: string; // e.g., 'github', 'zendesk', 'ab-tasty'
  key: string;
  addedAt: string;
  expiresAt?: string;
  notes?: string;
}

export class RotatingKeyManager {
  private vault: Map<string, StoredKey[]> = new Map();

  addKey(service: string, key: string, opts: Partial<StoredKey> = {}){
    const list = this.vault.get(service) ?? [];
    list.push({
      service,
      key,
      addedAt: new Date().toISOString(),
      ...opts
    });
    this.vault.set(service, list);
  }

  list(service?: string){
    if(service) return this.vault.get(service) ?? [];
    return Array.from(this.vault.values()).flat();
  }

  rotate(service: string, newKey: string){
    const list = this.vault.get(service) ?? [];
    list.push({ service, key: newKey, addedAt: new Date().toISOString() });
    this.vault.set(service, list);
    // TODO: revoke old keys via provider APIs where possible
  }

  nextToExpire(withinDays = 7){
    const soon: StoredKey[] = [];
    const now = Date.now();
    for(const arr of this.vault.values()){
      for(const k of arr){
        if(!k.expiresAt) continue;
        const diffDays = (Date.parse(k.expiresAt) - now) / 86400000;
        if(diffDays <= withinDays) soon.push(k);
      }
    }
    return soon;
  }
}
