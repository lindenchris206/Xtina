/**
 * AccessibilityControls.jsx
 * Text-size and zoom toggles for seniors-friendly UI.
 * Usage: place in topbar. Persists to localStorage.
 */
import React from 'react';

const KEY = 'xtina-ui-accessibility';

function clamp(n, min, max){ return Math.max(min, Math.min(max, n)); }

export default function AccessibilityControls(){
  const [textScale, setTextScale] = React.useState(1.0);
  const [zoom, setZoom] = React.useState(1.0);

  React.useEffect(()=>{
    try {
      const raw = localStorage.getItem(KEY);
      if(raw){
        const { textScale: ts, zoom: z } = JSON.parse(raw);
        setTextScale(ts ?? 1.0);
        setZoom(z ?? 1.0);
        document.documentElement.style.setProperty('--xtina-text-scale', ts ?? 1.0);
        document.body.style.transform = `scale(${z ?? 1.0})`;
        document.body.style.transformOrigin = 'top left';
      }
    } catch {}
  }, []);

  const persist = (next)=>{
    localStorage.setItem(KEY, JSON.stringify(next));
  };

  const changeText = (delta)=>{
    const next = clamp(parseFloat((textScale + delta).toFixed(2)), 0.8, 1.8);
    setTextScale(next);
    document.documentElement.style.setProperty('--xtina-text-scale', next);
    persist({ textScale: next, zoom });
  };

  const changeZoom = (delta)=>{
    const next = clamp(parseFloat((zoom + delta).toFixed(2)), 0.8, 1.5);
    setZoom(next);
    document.body.style.transform = `scale(${next})`;
    document.body.style.transformOrigin = 'top left';
    persist({ textScale, zoom: next });
  };

  return (
    <div className="flex items-center gap-2">
      <div className="flex items-center gap-1">
        <button onClick={()=>changeText(-0.1)} aria-label="Decrease text size">A-</button>
        <span>Text</span>
        <button onClick={()=>changeText(+0.1)} aria-label="Increase text size">A+</button>
      </div>
      <div className="flex items-center gap-1">
        <button onClick={()=>changeZoom(-0.1)} aria-label="Zoom out">-</button>
        <span>Zoom</span>
        <button onClick={()=>changeZoom(+0.1)} aria-label="Zoom in">+</button>
        <button onClick={()=>{ setZoom(1.0); document.body.style.transform = 'scale(1)'; persist({ textScale, zoom: 1.0 }); }} aria-label="Reset zoom">100%</button>
      </div>
    </div>
  );
}
