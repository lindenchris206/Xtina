import React from 'react'

function readLocalBundles(){
  try{
    const keys = Object.keys(localStorage).filter(k=>k.startsWith('bundle:'))
    const list = keys.map(k=> JSON.parse(localStorage.getItem(k))).filter(Boolean)
    return list
  }catch{return []}
}

export default function KnowledgeCarousel(){
  const [bundles, setBundles] = React.useState(()=> readLocalBundles())

  React.useEffect(()=>{
    const on = ()=> setBundles(readLocalBundles())
    window.addEventListener('storage', on)
    return ()=> window.removeEventListener('storage', on)
  }, [])

  const sorted = bundles.slice().sort((a,b)=> a.title.localeCompare(b.title))

  return (
    <div className="flex gap-2 overflow-x-auto py-2">
      {sorted.map(b=>(
        <div key={b.id} className="min-w-[220px] rounded-xl border p-3">
          <div className="font-medium">{b.title}</div>
          <div className="text-xs opacity-60">{(b.tags||[]).join(', ')}</div>
          <div className="text-xs mt-1 opacity-70">{new Date(b.createdAt).toLocaleString()}</div>
        </div>
      ))}
      {sorted.length===0 && <div className="text-sm opacity-60">No bundles yet. Drop files/links into the Floating Widget to create one.</div>}
    </div>
  )
}
