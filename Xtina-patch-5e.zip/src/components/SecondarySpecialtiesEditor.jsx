import React from 'react'
import { AgentRegistryCtx } from '../agents'
import { SPECIALTIES } from '../agents/specialties'
import KnowledgeCarousel from './KnowledgeCarousel'

export default function SecondarySpecialtiesEditor({ agentId }:{
  agentId: string
}){
  const reg = React.useContext(AgentRegistryCtx)
  const agent = reg?.get(agentId)
  const [secondaries, setSecondaries] = React.useState(agent?.secondarySpecialties ?? [])

  const update = (vals)=>{
    setSecondaries(vals)
    reg?.update(agentId, { secondarySpecialties: vals })
  }

  return (
    <div className="space-y-3">
      <div className="text-sm opacity-70">Secondary specialties (2–4):</div>
      <div className="flex flex-wrap gap-2">
        {SPECIALTIES.slice().sort((a,b)=>a.localeCompare(b)).map(sp=>{
          const on = secondaries.includes(sp as any)
          return (
            <button key={sp}
              className={`px-2 py-1 rounded-full border ${on ? 'bg-zinc-200 dark:bg-zinc-800' : ''}`}
              onClick={()=>{
                let next = on ? secondaries.filter(s=>s!==sp) : [...secondaries, sp as any]
                if(next.length>4) next = next.slice(0,4)
                update(next)
              }}
            >{sp}</button>
          )
        })}
      </div>

      <div className="pt-2 border-t">
        <div className="text-sm font-medium mb-1">Knowledge Bases (A→Z)</div>
        <KnowledgeCarousel />
      </div>
    </div>
  )
}
