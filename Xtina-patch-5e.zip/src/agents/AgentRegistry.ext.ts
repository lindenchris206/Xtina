// AgentRegistry.ts (extended)
import { SPECIALTIES, Specialty } from './specialties'

export interface KnowledgeBundleRef {
  id: string;
  title: string;
  tags: string[];
  manifestPath?: string;
}

export interface AgentConfig {
  id: string;
  name: string;
  role: 'lead' | 'specialist' | 'generalist';
  engine: 'gpt' | 'llama' | 'mistral' | 'custom';
  primarySpecialties: Specialty[];
  secondarySpecialties: Specialty[];
  bundles: KnowledgeBundleRef[];
  assistantIds: string[]; // 2-3 assistants each
  enabled: boolean;
}

const PERSIST_KEY = 'xtina:agents';

export class AgentRegistry {
  private agents: Map<string, AgentConfig> = new Map();

  constructor(){
    // hydrate from storage if present
    try {
      const raw = localStorage.getItem(PERSIST_KEY);
      if(raw){
        const parsed: AgentConfig[] = JSON.parse(raw);
        parsed.forEach(a=> this.agents.set(a.id, a));
      }
    } catch {}
  }

  private persist(){
    try { localStorage.setItem(PERSIST_KEY, JSON.stringify(this.list())); } catch {}
  }

  add(agent: AgentConfig){
    this.agents.set(agent.id, agent);
    this.persist();
  }

  list(){
    return Array.from(this.agents.values());
  }

  get(id: string){
    return this.agents.get(id);
  }

  update(id: string, patch: Partial<AgentConfig>){
    const a = this.agents.get(id);
    if(!a) throw new Error('Agent not found');
    const next = { ...a, ...patch };
    this.agents.set(id, next);
    this.persist();
  }

  attachBundle(agentId: string, bundle: KnowledgeBundleRef){
    const a = this.agents.get(agentId);
    if(!a) throw new Error('Agent not found');
    a.bundles.push(bundle);
    this.persist();
  }

  suggestAgentByTags(tags: string[]): AgentConfig[] {
    const score = (a: AgentConfig)=>{
      let s = 0;
      for(const t of tags){
        if(a.primarySpecialties.includes(t as Specialty)) s += 3;
        if(a.secondarySpecialties.includes(t as Specialty)) s += 1;
      }
      return s;
    };
    return this.list().sort((a,b)=>score(b)-score(a));
  }
}

export function bootstrapDefaultAgents(){
  const reg = new AgentRegistry();
  if(reg.list().length) return reg; // already hydrated

  reg.add({
    id: 'renee',
    name: 'Renee',
    role: 'lead',
    engine: 'gpt',
    primarySpecialties: ['orchestration' as any] as Specialty[], // keep existing custom tag if any
    secondarySpecialties: ['research' as any, 'security' as any] as Specialty[],
    bundles: [],
    assistantIds: ['librarian','analyst'],
    enabled: true
  });
  reg.add({
    id: 'agent-a',
    name: 'Analyst A',
    role: 'specialist',
    engine: 'mistral',
    primarySpecialties: ['research' as any,'summarization' as any] as Specialty[],
    secondarySpecialties: ['writing' as any,'planning' as any] as Specialty[],
    bundles: [],
    assistantIds: ['scribe','librarian'],
    enabled: true
  });
  reg.add({
    id: 'agent-b',
    name: 'Builder B',
    role: 'specialist',
    engine: 'llama',
    primarySpecialties: ['coding' as any,'refactor' as any] as Specialty[],
    secondarySpecialties: ['testing' as any,'docs' as any] as Specialty[],
    bundles: [],
    assistantIds: ['engineer','scribe'],
    enabled: true
  });
  return reg;
}
