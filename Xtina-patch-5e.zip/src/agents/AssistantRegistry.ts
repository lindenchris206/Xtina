// AssistantRegistry.ts
export interface Assistant {
  id: string;
  name: string;
  skills: string[]; // simple tags
}

export class AssistantRegistry {
  private map = new Map<string, Assistant>();
  add(a: Assistant){ this.map.set(a.id, a); return this; }
  get(id: string){ return this.map.get(id); }
  list(){ return Array.from(this.map.values()); }
}

export function bootstrapAssistants(){
  const reg = new AssistantRegistry();
  reg.add({ id:'scribe', name:'Scribe', skills:['writing','summarization','formatting'] });
  reg.add({ id:'librarian', name:'Librarian', skills:['research','retrieval','citation'] });
  reg.add({ id:'engineer', name:'Engineer', skills:['coding','refactor','tests'] });
  reg.add({ id:'analyst', name:'Analyst', skills:['analysis','math','finance'] });
  reg.add({ id:'designer', name:'Designer', skills:['art','design'] });
  return reg;
}
