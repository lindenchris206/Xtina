// src/agents/debate/DebateProtocol.ts
import { AgentRegistry } from '../AgentRegistry.ext'

export type DebateStage = 'brief' | 'proposals' | 'cross' | 'revision' | 'vote' | 'synthesis'

export interface DebateConfig {
  topic: string
  agentIds: string[]
  rounds?: number
  maxTokens?: number
}

export interface Turn {
  stage: DebateStage
  agentId: string
  content: string
  meta?: Record<string, any>
}

export interface Vote {
  voterId: string
  forAgentId: string
  scores: { evidence:number, correctness:number, specificity:number, robustness:number, safety:number }
  notes?: string
}

export interface DebateResult {
  transcript: Turn[]
  votes: Vote[]
  winnerId?: string
  synthesis?: string
  rubric?: string[]
}

export class Debate {
  private transcript: Turn[] = []
  private votes: Vote[] = []
  private rubric = ['evidence','correctness','specificity','robustness','safety']

  constructor(private reg: AgentRegistry, private cfg: DebateConfig){
    if (cfg.agentIds.length < 2) throw new Error('Need at least 2 agents to debate')
  }

  getTranscript(){ return this.transcript }
  getVotes(){ return this.votes }
  getRubric(){ return this.rubric }

  addBrief(agentId:string, content:string){
    this.transcript.push({ stage:'brief', agentId, content })
  }

  addProposal(agentId:string, content:string){
    this.transcript.push({ stage:'proposals', agentId, content })
  }

  addCross(agentId:string, content:string){
    this.transcript.push({ stage:'cross', agentId, content })
  }

  addRevision(agentId:string, content:string){
    this.transcript.push({ stage:'revision', agentId, content })
  }

  addVote(v: Vote){
    this.votes.push(v)
  }

  computeWinner(){
    // Average total score; tie-breaker: highest evidence then correctness
    const byAgent: Record<string,{sum:number,count:number, evidence:number, correctness:number}> = {}
    for(const v of this.votes){
      const total = v.scores.evidence + v.scores.correctness + v.scores.specificity + v.scores.robustness + v.scores.safety
      const a = byAgent[v.forAgentId] || { sum:0, count:0, evidence:0, correctness:0 }
      a.sum += total; a.count += 1
      a.evidence += v.scores.evidence
      a.correctness += v.scores.correctness
      byAgent[v.forAgentId] = a
    }
    let winnerId: string | undefined
    let best = -1
    for(const [aid, s] of Object.entries(byAgent)){
      const score = s.sum / Math.max(1, s.count)
      if(score > best) { best = score; winnerId = aid }
      else if(score === best && winnerId){
        const w = byAgent[winnerId]
        if(s.evidence > w.evidence || (s.evidence===w.evidence && s.correctness > w.correctness)) winnerId = aid
      }
    }
    return winnerId
  }

  synthesize(): string {
    // Simple synthesis: stitch best parts from revisions if present, else proposals
    const buckets = ['revision','proposals'] as DebateStage[]
    const parts: string[] = []
    for(const b of buckets){
      for(const t of this.transcript){
        if(t.stage===b) parts.push(`(${t.agentId} ${b}) ${t.content}`)
      }
      if(parts.length) break
    }
    const intro = `Synthesis for: ${this.cfg.topic}. Criteria: ${this.rubric.join(', ')}.\n`
    return intro + parts.join('\n\n') + '\n\nConsensus: Emphasize evidence-backed, testable claims; flag uncertainties.'
  }

  finish(): DebateResult {
    const winnerId = this.computeWinner()
    const synthesis = this.synthesize()
    return { transcript: this.transcript, votes: this.votes, winnerId, synthesis, rubric: this.rubric }
  }
}
