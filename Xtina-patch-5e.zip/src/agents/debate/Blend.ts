// src/agents/debate/Blend.ts
import type { DebateResult } from './DebateProtocol'

export interface BlendConfig {
  weights?: { evidence:number, correctness:number, specificity:number, robustness:number, safety:number }
}

export function blend(result: DebateResult, cfg: BlendConfig = {}): { answer:string, rationale:string } {
  const w = Object.assign({ evidence:1, correctness:1, specificity:0.7, robustness:0.6, safety:0.9 }, cfg.weights || {})
  // Weighted winner confidence
  const byAgent: Record<string,{score:number}> = {}
  for(const v of result.votes){
    const s = v.scores
    const sc = s.evidence*w.evidence + s.correctness*w.correctness + s.specificity*w.specificity + s.robustness*w.robustness + s.safety*w.safety
    byAgent[v.forAgentId] = { score: (byAgent[v.forAgentId]?.score || 0) + sc }
  }
  const best = Object.entries(byAgent).sort((a,b)=> b[1].score - a[1].score)[0]?.[0] || result.winnerId
  const fragments = result.transcript.filter(t=> t.agentId===best && (t.stage==='revision' || t.stage==='proposals')).map(t=> t.content)
  const answer = fragments.join('\n\n').slice(0, 4000) || result.synthesis || 'No content'
  const rationale = `Chosen by weighted vote favoring evidence and correctness. Winner: ${best || 'N/A'}.`
  return { answer, rationale }
}
