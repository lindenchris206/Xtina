// AgentRegistry.ts
// Minimal registry for agents with primary/secondary specialties and bundle affinity.

export type Specialty = string;

export interface KnowledgeBundleRef {
  id: string;
  title: string;
  tags: string[];
  manifestPath?: string;
}

export interface AgentConfig {
  id: string;
  name: string;
  role: 'lead' | 'specialist' | 'generalist';
  engine: 'gpt' | 'llama' | 'mistral' | 'custom';
  primarySpecialties: Specialty[];
  secondarySpecialties: Specialty[];
  bundles: KnowledgeBundleRef[];
  enabled: boolean;
}

export class AgentRegistry {
  private agents: Map<string, AgentConfig> = new Map();

  add(agent: AgentConfig){
    this.agents.set(agent.id, agent);
  }

  list(){
    return Array.from(this.agents.values());
  }

  get(id: string){
    return this.agents.get(id);
  }

  attachBundle(agentId: string, bundle: KnowledgeBundleRef){
    const a = this.agents.get(agentId);
    if(!a) throw new Error('Agent not found');
    a.bundles.push(bundle);
  }

  suggestAgentByTags(tags: string[]): AgentConfig[] {
    const score = (a: AgentConfig)=>{
      let s = 0;
      for(const t of tags){
        if(a.primarySpecialties.includes(t)) s += 3;
        if(a.secondarySpecialties.includes(t)) s += 1;
      }
      return s;
    };
    return this.list().sort((a,b)=>score(b)-score(a));
  }
}

// Sample bootstrap
export function bootstrapDefaultAgents(){
  const reg = new AgentRegistry();
  reg.add({
    id: 'renee',
    name: 'Renee',
    role: 'lead',
    engine: 'gpt',
    primarySpecialties: ['orchestration','planning','comms'],
    secondarySpecialties: ['research','security'],
    bundles: [],
    enabled: true
  });
  reg.add({
    id: 'agent-a',
    name: 'Analyst A',
    role: 'specialist',
    engine: 'mistral',
    primarySpecialties: ['research','summarization'],
    secondarySpecialties: ['writing','planning'],
    bundles: [],
    enabled: true
  });
  reg.add({
    id: 'agent-b',
    name: 'Builder B',
    role: 'specialist',
    engine: 'llama',
    primarySpecialties: ['coding','refactor'],
    secondarySpecialties: ['testing','docs'],
    bundles: [],
    enabled: true
  });
  return reg;
}
