# Connections
Central place to manage external integrations and API keys.

- GitHub
- GitGuardian (best practices / scanning)
- Keystatic (content)
- AB Tasty
- Zendesk
- Custom services

Use the Key Manager to store & rotate keys. Ensure `.env` is not committed.
