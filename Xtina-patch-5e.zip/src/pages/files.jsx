import React from 'react'
import { fsList, fsMkdir, fsWrite, fsDelete, fsMove, fsCopy, fsZip, fsUnzip, fsRead } from '../lib/fsClient'

function prettySize(b){
  if(b<1024) return b+' B'
  if(b<1024*1024) return (b/1024).toFixed(1)+' KB'
  if(b<1024*1024*1024) return (b/1024/1024).toFixed(1)+' MB'
  return (b/1024/1024/1024).toFixed(1)+' GB'
}

function Breadcrumbs({path, onNav}){
  const parts = path.split('/').filter(Boolean)
  const crumbs = ['/', ...parts.map((_,i)=> '/'+parts.slice(0,i+1).join('/'))]
  return (
    <div className="text-sm">
      {crumbs.map((p,i)=>(
        <span key={p}>
          <button className="underline" onClick={()=>onNav(p)}>{i===0? 'root' : parts[i-1]}</button>
          {i<crumbs.length-1 && ' / '}
        </span>
      ))}
    </div>
  )
}

export default function FileExplorer(){
  const [cwd, setCwd] = React.useState('/')
  const [entries, setEntries] = React.useState([])
  const [selected, setSelected] = React.useState(null)
  const [preview, setPreview] = React.useState(null)
  const [filter, setFilter] = React.useState('')

  const load = async (dir=cwd)=> {
    const { entries } = await fsList(dir)
    setEntries(entries); setSelected(null); setPreview(null)
    setCwd(dir)
  }
  React.useEffect(()=>{ load('/') },[])

  const enter = (e)=>{
    const next = (cwd.endsWith('/')? cwd : cwd + '/') + e.name
    if(e.isDir) load(next)
    else setSelected(next)
  }

  const makeDir = async ()=>{
    const name = prompt('Folder name')
    if(!name) return
    const p = (cwd.endsWith('/')? cwd : cwd + '/') + name
    await fsMkdir(p); load()
  }

  const createFile = async ()=>{
    const name = prompt('File name (e.g., notes.txt)')
    if(!name) return
    const p = (cwd.endsWith('/')? cwd : cwd + '/') + name
    await fsWrite(p, '')
    load()
  }

  const del = async ()=>{
    if(!selected) return
    if(!confirm('Delete '+selected+' ?')) return
    await fsDelete(selected); load()
  }

  const rename = async ()=>{
    if(!selected) return
    const base = selected.split('/').pop()
    const nextName = prompt('Rename to', base) || base
    const dst = selected.replace(/[^/]+$/, nextName)
    await fsMove(selected, dst); load()
  }

  const copyTo = async ()=>{
    if(!selected) return
    const dst = prompt('Copy to (absolute under root)', selected+'-copy')
    if(!dst) return
    await fsCopy(selected, dst); load()
  }

  const zipSel = async ()=>{
    if(!selected) return
    const out = prompt('Zip to', selected.replace(/\/?$/, '') + '.zip')
    if(!out) return
    await fsZip([selected], out); alert('Zipped: '+out); load()
  }

  const unzipSel = async ()=>{
    if(!selected) return
    const out = prompt('Unzip into', cwd)
    if(!out) return
    await fsUnzip(selected, out); alert('Unzipped into: '+out); load(out)
  }

  const showPreview = async ()=>{
    if(!selected) return
    const buf = await fsRead(selected)
    // naive type check
    const isText = /\.((txt|md|json|js|ts|jsx|tsx|css|html|csv|env))$/i.test(selected)
    const isImage = /\.(png|jpg|jpeg|gif|webp|bmp|svg)$/i.test(selected)
    const isAudio = /\.(mp3|wav|ogg|m4a)$/i.test(selected)
    const isVideo = /\.(mp4|webm|mov|mkv)$/i.test(selected)
    if(isText){
      const dec = new TextDecoder('utf-8').decode(buf)
      setPreview({ type:'text', content: dec })
    }else if(isImage){
      const blob = new Blob([buf])
      setPreview({ type:'image', url: URL.createObjectURL(blob) })
    }else if(isAudio){
      const blob = new Blob([buf])
      setPreview({ type:'audio', url: URL.createObjectURL(blob) })
    }else if(isVideo){
      const blob = new Blob([buf])
      setPreview({ type:'video', url: URL.createObjectURL(blob) })
    }else{
      setPreview({ type:'hex', content: Array.from(buf.slice(0,2048)).map(b=>b.toString(16).padStart(2,'0')).join(' ') })
    }
  }

  const onDrop = async (ev)=>{
    ev.preventDefault()
    const file = ev.dataTransfer.files?.[0]
    if(!file) return
    const body = new FormData()
    body.append('file', file)
    const res = await fetch('/api/fs/upload?dst='+encodeURIComponent(cwd), { method:'POST', body })
    if(!res.ok) alert(await res.text())
    else load()
  }

  const list = entries.filter(e=> !filter || e.name.toLowerCase().includes(filter.toLowerCase()))

  return (
    <div className="grid grid-cols-[22rem_1fr] gap-4" onDragOver={e=>e.preventDefault()} onDrop={onDrop}>
      <div className="border rounded-2xl p-3">
        <div className="font-medium">Files</div>
        <div className="mt-2"><Breadcrumbs path={cwd} onNav={load}/></div>
        <div className="mt-2 flex gap-2">
          <button className="px-2 py-1 border rounded" onClick={makeDir}>New Folder</button>
          <button className="px-2 py-1 border rounded" onClick={createFile}>New File</button>
        </div>
        <input className="mt-2 w-full border rounded px-2 py-1" placeholder="Filter…" value={filter} onChange={e=>setFilter(e.target.value)} />
        <ul className="mt-2 max-h-[60vh] overflow-auto text-sm">
          {list.map(e=>(
            <li key={e.path}
              className={`flex justify-between px-2 py-1 rounded cursor-pointer ${selected===((cwd.endsWith('/')?cwd:cwd+'/')+e.name)? 'bg-zinc-200 dark:bg-zinc-800':''}`}
              onClick={()=> setSelected((cwd.endsWith('/')?cwd:cwd+'/')+e.name)}
              onDoubleClick={()=> enter(e)}
            >
              <span>{e.isDir ? '📁' : '📄'} {e.name}</span>
              <span className="opacity-60">{e.isDir? '—' : prettySize(e.size)}</span>
            </li>
          ))}
          {list.length===0 && <li className="opacity-60 px-2 py-1">Empty</li>}
        </ul>
      </div>

      <div className="border rounded-2xl p-3">
        <div className="flex items-center justify-between">
          <div className="font-medium">Details</div>
          <div className="flex gap-2">
            <button className="px-2 py-1 border rounded" onClick={rename} disabled={!selected}>Rename</button>
            <button className="px-2 py-1 border rounded" onClick={copyTo} disabled={!selected}>Copy</button>
            <button className="px-2 py-1 border rounded" onClick={zipSel} disabled={!selected}>Zip</button>
            <button className="px-2 py-1 border rounded" onClick={unzipSel} disabled={!selected || !/\.zip$/i.test(selected)}>Unzip</button>
            <button className="px-2 py-1 border rounded" onClick={del} disabled={!selected}>Delete</button>
            <button className="px-2 py-1 border rounded" onClick={showPreview} disabled={!selected}>Preview</button>
          </div>
        </div>

        {!selected && <div className="text-sm opacity-60 mt-2">Select a file/folder. Drag files here to upload into the current folder.</div>}

        {preview?.type==='text' && (
          <textarea className="w-full h-[60vh] mt-2 border rounded px-2 py-1" defaultValue={preview.content}
            onBlur={async(e)=>{ await fsWrite(selected, e.target.value); }} />
        )}
        {preview?.type==='image' && <img alt="" src={preview.url} className="max-h-[60vh] mt-2 rounded"/>}
        {preview?.type==='audio' && <audio controls src={preview.url} className="w-full mt-2"/>}
        {preview?.type==='video' && <video controls src={preview.url} className="w-full mt-2 max-h-[60vh]"/>}
        {preview?.type==='hex' && <pre className="mt-2 text-xs whitespace-pre-wrap">{preview.content}</pre>}
      </div>
    </div>
  )
}
