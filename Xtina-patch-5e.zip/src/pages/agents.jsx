import React from 'react'
import { AgentRegistryCtx } from '../agents'
import SecondarySpecialtiesEditor from '../components/SecondarySpecialtiesEditor'
import { bootstrapAssistants } from '../agents/AssistantRegistry'

const assistants = bootstrapAssistants()

export default function AgentsPage(){
  const reg = React.useContext(AgentRegistryCtx)
  const agents = reg?.list() ?? []
  return (
    <div className="grid gap-4">
      {agents.map(a=>{
        return (
          <div key={a.id} className="border rounded-2xl p-4">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-lg font-semibold">{a.name} <span className="opacity-60">({a.role})</span></div>
                <div className="text-sm">Engine: {a.engine}</div>
                <div className="text-sm">Primary: {a.primarySpecialties.join(', ')||'—'}</div>
                <div className="text-sm">Assistants: {a.assistantIds.map(id=> assistants.get(id)?.name || id).join(', ')}</div>
              </div>
              <button className="px-3 py-2 border rounded-lg" onClick={()=>{
                const all = assistants.list().map(x=>x.id+':'+x.name).join('\n')
                alert('Available assistants:\n'+all+'\n\nEdit mapping in Agent settings soon.')
              }}>Change assistants</button>
            </div>

            <div className="mt-3">
              <SecondarySpecialtiesEditor agentId={a.id} />
            </div>
          </div>
        )
      })}
    </div>
  )
}
