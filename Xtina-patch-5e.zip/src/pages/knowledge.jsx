import React from 'react'
import KnowledgeCarousel from '../components/KnowledgeCarousel'

function readLocalBundles(){
  try{
    const keys = Object.keys(localStorage).filter(k=>k.startsWith('bundle:'))
    return keys.map(k=> JSON.parse(localStorage.getItem(k))).filter(Boolean)
  }catch{return []}
}

export default function KnowledgePage(){
  const [bundles, setBundles] = React.useState(readLocalBundles())
  const [title, setTitle] = React.useState('New Bundle')
  const [tags, setTags] = React.useState('general')

  const create = ()=>{
    const id = Date.now().toString(36)
    const manifest = { id, title, tags: tags.split(',').map(s=>s.trim()), items:[], createdAt: new Date().toISOString() }
    localStorage.setItem('bundle:'+id, JSON.stringify(manifest))
    setBundles(readLocalBundles())
  }

  return (
    <div className="space-y-4">
      <h1 className="text-xl font-semibold">Knowledge Bases</h1>
      <div className="rounded-xl border p-3">
        <div className="text-sm opacity-70 mb-2">Create bundle</div>
        <div className="flex gap-2">
          <input className="border rounded px-2" value={title} onChange={e=>setTitle(e.target.value)} placeholder="Title" />
          <input className="border rounded px-2" value={tags} onChange={e=>setTags(e.target.value)} placeholder="tags (comma separated)" />
          <button className="px-3 py-2 rounded-lg border" onClick={create}>Add</button>
        </div>
      </div>
      <div className="rounded-xl border p-3">
        <div className="text-sm font-medium mb-2">All bundles (A→Z)</div>
        <KnowledgeCarousel />
      </div>
      <div className="rounded-xl border p-3">
        <div className="text-sm opacity-70 mb-2">Manage</div>
        <ul className="space-y-2">
          {bundles.sort((a,b)=>a.title.localeCompare(b.title)).map(b=>(
            <li key={b.id} className="flex justify-between items-center border rounded px-2 py-1">
              <div>
                <div className="font-medium">{b.title}</div>
                <div className="text-xs opacity-60">{(b.tags||[]).join(', ')}</div>
              </div>
              <div className="flex gap-2">
                <button className="px-2 py-1 border rounded" onClick={()=>{
                  const nextTitle = prompt('Rename bundle', b.title) || b.title
                  b.title = nextTitle
                  localStorage.setItem('bundle:'+b.id, JSON.stringify(b))
                  setBundles(readLocalBundles())
                }}>Rename</button>
                <button className="px-2 py-1 border rounded" onClick={()=>{
                  if(confirm('Delete this bundle?')){
                    localStorage.removeItem('bundle:'+b.id)
                    setBundles(readLocalBundles())
                  }
                }}>Delete</button>
              </div>
            </li>
          ))}
          {bundles.length===0 && <li className="text-sm opacity-60">No bundles yet.</li>}
        </ul>
      </div>
    </div>
  )
}
