import React from 'react'
import { AgentRegistryCtx } from '../agents'
import { Debate } from '../agents/debate/DebateProtocol'
import { blend } from '../agents/debate/Blend'

function ScoreInput({value,onChange}){
  const [v,setV] = React.useState(value||{evidence:3,correctness:3,specificity:3,robustness:3,safety:3})
  React.useEffect(()=>{ onChange?.(v) },[v])
  const Field = ({k})=>(
    <label className="flex items-center gap-2 text-xs">
      <span className="w-20 capitalize">{k}</span>
      <input type="range" min="1" max="5" value={v[k]} onChange={e=> setV({...v,[k]:Number(e.target.value)})}/>
      <span className="w-4 text-right">{v[k]}</span>
    </label>
  )
  return (<div className="grid grid-cols-2 gap-2">
    <Field k="evidence"/><Field k="correctness"/><Field k="specificity"/><Field k="robustness"/><Field k="safety"/>
  </div>)
}

export default function DebateRoom(){
  const reg = React.useContext(AgentRegistryCtx)
  const [topic, setTopic] = React.useState('Propose a rollout plan for the new feature without downtime.')
  const [selected, setSelected] = React.useState([])
  const [debate, setDebate] = React.useState(null)
  const [transcript, setTranscript] = React.useState([])
  const [votes, setVotes] = React.useState([])
  const [finalBlend, setFinalBlend] = React.useState(null)

  const agents = reg?.list() ?? []

  const toggle = (id)=> setSelected(s=> s.includes(id) ? s.filter(x=>x!==id) : [...s, id])

  const addTurn = (stage, agentId, content)=>{
    setTranscript(t=> [...t, { stage, agentId, content }])
  }

  const start = ()=>{
    if(selected.length<2) { alert('Pick at least two agents.'); return }
    const d = new Debate(reg, { topic, agentIds: selected })
    setDebate(d); setTranscript([]); setVotes([]); setFinalBlend(null)
  }

  const quickAuto = ()=>{
    if(!debate){ alert('Start a debate first'); return }
    // Fake content generators for demo (replace with real model calls)
    for(const aid of selected){
      addTurn('brief', aid, `Perspective of ${aid}: key risks and assumptions.`)
    }
    for(const aid of selected){
      addTurn('proposals', aid, `Proposal by ${aid}: Step-by-step plan with milestones.`)
    }
    for(const aid of selected){
      addTurn('cross', aid, `Critique by ${aid}: challenges and missing evidence.`)
    }
    for(const aid of selected){
      addTurn('revision', aid, `Revision by ${aid}: updated plan incorporating critiques.`)
    }
  }

  const castVotes = ()=>{
    if(!debate){ alert('Start a debate first'); return }
    const nextVotes = selected.map((voter,i)=>{
      const forAgentId = selected[(i+1)%selected.length] // round-robin vote for demo
      return { voterId: voter, forAgentId, scores: { evidence:4, correctness:4, specificity:3, robustness:3, safety:4 }, notes: 'demo vote' }
    })
    setVotes(nextVotes)
  }

  const finish = ()=>{
    if(!debate){ alert('Start a debate first'); return }
    // hydrate the instance (mirror state kept in component)
    transcript.forEach(t=> {
      if(t.stage==='brief') debate.addBrief(t.agentId, t.content)
      if(t.stage==='proposals') debate.addProposal(t.agentId, t.content)
      if(t.stage==='cross') debate.addCross(t.agentId, t.content)
      if(t.stage==='revision') debate.addRevision(t.agentId, t.content)
    })
    votes.forEach(v=> debate.addVote(v))
    const result = debate.finish()
    const blended = blend(result)
    setFinalBlend(blended)
  }

  return (
    <div className="space-y-4">
      <h1 className="text-xl font-semibold">Deliberation Room</h1>
      <div className="rounded-xl border p-3 space-y-2">
        <label className="text-sm">Topic</label>
        <input className="w-full border rounded px-2 py-1" value={topic} onChange={e=>setTopic(e.target.value)} />
        <div className="text-sm mt-2">Agents</div>
        <div className="flex flex-wrap gap-2">
          {agents.map(a=>(
            <button key={a.id}
              className={`px-3 py-1 rounded-full border ${selected.includes(a.id)?'bg-zinc-200 dark:bg-zinc-800':''}`}
              onClick={()=>toggle(a.id)}>
              {a.name}
            </button>
          ))}
        </div>
        <div className="flex gap-2 mt-2">
          <button className="px-3 py-2 border rounded" onClick={start}>Start</button>
          <button className="px-3 py-2 border rounded" onClick={quickAuto}>Auto-run demo</button>
          <button className="px-3 py-2 border rounded" onClick={castVotes}>Auto-vote demo</button>
          <button className="px-3 py-2 border rounded" onClick={finish}>Finish & Blend</button>
        </div>
      </div>

      <div className="rounded-xl border p-3">
        <div className="font-medium">Transcript</div>
        <ul className="mt-2 space-y-2 text-sm">
          {transcript.map((t,i)=>(
            <li key={i} className="border rounded p-2">
              <div className="opacity-60">{t.stage} — {t.agentId}</div>
              <div>{t.content}</div>
            </li>
          ))}
          {transcript.length===0 && <li className="text-sm opacity-60">No turns yet.</li>}
        </ul>
      </div>

      <div className="rounded-xl border p-3">
        <div className="font-medium">Votes</div>
        <div className="text-xs opacity-70">Each voter rates another agent across five criteria.</div>
        <ul className="mt-2 space-y-2 text-sm">
          {votes.map((v,i)=>(
            <li key={i} className="border rounded p-2 flex justify-between">
              <div>{v.voterId} → <b>{v.forAgentId}</b></div>
              <div className="opacity-70">e{v.scores.evidence} c{v.scores.correctness} s{v.scores.specificity} r{v.scores.robustness} sf{v.scores.safety}</div>
            </li>
          ))}
          {votes.length===0 && <li className="text-sm opacity-60">No votes yet.</li>}
        </ul>
      </div>

      {finalBlend && (
        <div className="rounded-xl border p-3">
          <div className="font-medium">Blended Answer</div>
          <pre className="whitespace-pre-wrap text-sm mt-2">{finalBlend.answer}</pre>
          <div className="text-xs opacity-60 mt-2">{finalBlend.rationale}</div>
        </div>
      )}
    </div>
  )
}
