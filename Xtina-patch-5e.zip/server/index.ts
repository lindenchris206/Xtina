import express from 'express'
import fs from 'fs'
import fsp from 'fs/promises'
import path from 'path'
import multer from 'multer'
import archiver from 'archiver'
import unzipper from 'unzipper'

const app = express()
app.use(express.json({ limit: '25mb' }))

const ROOT = process.env.XTINA_ROOT || path.resolve(process.cwd(), 'workspace')
await fsp.mkdir(ROOT, { recursive: true })

function safeJoin(p){
  const target = path.resolve(ROOT, p || '.')
  if (!target.startsWith(ROOT)) throw new Error('Path escapes root')
  return target
}

function toEntryStats(p, st){
  return {
    path: p.replace(ROOT, '') || '/',
    name: path.basename(p) || '/',
    isDir: st.isDirectory(),
    size: st.size,
    mtime: st.mtimeMs
  }
}

app.get('/api/fs/list', async (req, res)=>{
  try{
    const dir = safeJoin(req.query.dir || '.')
    const names = await fsp.readdir(dir)
    const stats = await Promise.all(names.map(async n=>{
      const full = path.join(dir, n)
      const st = await fsp.stat(full)
      return toEntryStats(full, st)
    }))
    res.json({ ok:true, root: ROOT, entries: stats.sort((a,b)=>{
      if(a.isDir!==b.isDir) return a.isDir? -1 : 1
      return a.name.localeCompare(b.name)
    })})
  }catch(err){ res.status(400).json({ ok:false, error: String(err) }) }
})

app.post('/api/fs/mkdir', async (req,res)=>{
  try{
    const full = safeJoin(req.body.path)
    await fsp.mkdir(full, { recursive: true })
    res.json({ ok:true })
  }catch(err){ res.status(400).json({ ok:false, error:String(err) })}
})

app.post('/api/fs/write', async (req,res)=>{
  try{
    const full = safeJoin(req.body.path)
    await fsp.mkdir(path.dirname(full), { recursive: true })
    await fsp.writeFile(full, req.body.content, 'utf8')
    res.json({ ok:true })
  }catch(err){ res.status(400).json({ ok:false, error:String(err) })}
})

app.post('/api/fs/read', async (req,res)=>{
  try{
    const full = safeJoin(req.body.path)
    const data = await fsp.readFile(full)
    res.type('application/octet-stream').send(data)
  }catch(err){ res.status(400).json({ ok:false, error:String(err) })}
})

app.post('/api/fs/delete', async (req,res)=>{
  try{
    const full = safeJoin(req.body.path)
    await fsp.rm(full, { recursive: true, force: true })
    res.json({ ok:true })
  }catch(err){ res.status(400).json({ ok:false, error:String(err) })}
})

app.post('/api/fs/move', async (req,res)=>{
  try{
    const src = safeJoin(req.body.src)
    const dst = safeJoin(req.body.dst)
    await fsp.mkdir(path.dirname(dst), { recursive: true })
    await fsp.rename(src, dst)
    res.json({ ok:true })
  }catch(err){ res.status(400).json({ ok:false, error:String(err) })}
})

app.post('/api/fs/copy', async (req,res)=>{
  try{
    const src = safeJoin(req.body.src)
    const dst = safeJoin(req.body.dst)
    await fsp.mkdir(path.dirname(dst), { recursive: true })
    await fsp.cp(src, dst, { recursive: true })
    res.json({ ok:true })
  }catch(err){ res.status(400).json({ ok:false, error:String(err) })}
})

const upload = multer({ dest: path.join(process.cwd(), '.uploadtmp') })
app.post('/api/fs/upload', upload.single('file'), async (req,res)=>{
  try{
    const dst = safeJoin(req.query.dst || '.')
    await fsp.mkdir(dst, { recursive: true })
    const filename = req.file?.originalname || 'upload.bin'
    await fsp.rename(req.file.path, path.join(dst, filename))
    res.json({ ok:true, name: filename })
  }catch(err){ res.status(400).json({ ok:false, error:String(err) })}
})

app.post('/api/fs/zip', async (req,res)=>{
  try{
    const outPath = safeJoin(req.body.out)
    await fsp.mkdir(path.dirname(outPath), { recursive: true })
    const output = fs.createWriteStream(outPath)
    const archive = archiver('zip', { zlib: { level: 9 } })
    archive.pipe(output)
    for(const p of req.body.paths || []){
      const full = safeJoin(p)
      const stat = await fsp.stat(full)
      if(stat.isDirectory()) archive.directory(full, path.basename(full))
      else archive.file(full, { name: path.basename(full) })
    }
    await archive.finalize()
    res.json({ ok:true, out: outPath })
  }catch(err){ res.status(400).json({ ok:false, error:String(err) })}
})

app.post('/api/fs/unzip', async (req,res)=>{
  try{
    const zipPath = safeJoin(req.body.zip)
    const outDir = safeJoin(req.body.outDir)
    await fsp.mkdir(outDir, { recursive: true })
    const stream = fs.createReadStream(zipPath).pipe(unzipper.Extract({ path: outDir }))
    await new Promise((resolve,reject)=>{ stream.on('close', resolve); stream.on('error', reject) })
    res.json({ ok:true, outDir })
  }catch(err){ res.status(400).json({ ok:false, error:String(err) })}
})

const PORT = Number(process.env.PORT || 8788)
app.listen(PORT, ()=> console.log('FS API on :'+PORT+' root='+ROOT))
