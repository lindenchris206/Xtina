import express from 'express'
const app=express();app.use(express.json());

import os from 'os'
import child_process from 'node:child_process'
function cpuSample(){const c=os.cpus();let i=0,t=0;for(const x of c){for(const k in x.times){t+=(x.times)[k];}i+=x.times.idle}return {idle:i,total:t}}
async function cpuPercent(ms=200){const a=cpuSample();await new Promise(r=>setTimeout(r,ms));const b=cpuSample();const idle=b.idle-a.idle;const total=b.total-a.total;return total>0? (1-idle/total)*100:0}
function memStats(){const T=os.totalmem(),F=os.freemem();const U=T-F;return {total:T,free:F,used:U,percent:T?U/T*100:0}}
function tryNvidia(){try{const out=child_process.execSync('nvidia-smi --query-gpu=name,memory.total,memory.used --format=csv,noheader',{stdio:['ignore','pipe','ignore'],timeout:500}).toString().trim();const line=out.split('\n')[0]||'';const p=line.split(',').map(s=>s.trim());if(p.length>=3){const t=parseFloat(p[1]);const u=parseFloat(p[2]);return {name:p[0],memoryTotalMB:t,memoryUsedMB:u,percent:t?u/t*100:null}}}catch{}return null}
app.get('/api/sys/stats', async (req,res)=>{try{const cpu=await cpuPercent(180);const mem=memStats();const load=os.loadavg();const gpu=tryNvidia();res.json({ok:true,time:Date.now(),cpu:{percent:cpu,load1:load[0],load5:load[1],load15:load[2]},memory:mem,gpu})}catch(e){res.status(500).json({ok:false,error:String(e)})}})

app.listen(8788,()=>console.log('FS API on :8788'))
