#!/usr/bin/env pwsh
$ErrorActionPreference = "Stop"
Write-Host "==> Xtina single-file installer (Windows)"
if (-not (Get-Command node -ErrorAction SilentlyContinue)) {
  Write-Host "NodeJS not found. Install Node 18+ from https://nodejs.org/en/download or via winget: winget install OpenJS.NodeJS"
  exit 1
}
$APP_DIR = Get-Location
Copy-Item "$APP_DIR\package.server.json" "$APP_DIR\package.json" -Force
Write-Host "==> Installing dependencies..."
npm i --silent
if (-not $env:XTINA_ROOT) { $env:XTINA_ROOT = "$APP_DIR\workspace" }
New-Item -ItemType Directory -Force -Path $env:XTINA_ROOT | Out-Null
Write-Host "==> Starting dev server (Ctrl+C to stop)"
npm run dev
