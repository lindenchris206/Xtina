
import React from 'react'
import ResourceMonitor from '../components/ResourceMonitor'
import '../styles/resmon.css'
async function list(){ const r=await fetch('/api/approvals'); return await r.json() }
async function decide(id, approve, note=''){ const r=await fetch('/api/approvals/'+id+'/decision',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({approve,note})}); return await r.json() }
export default function Approvals(){
  const [items,setItems]=React.useState([])
  const refresh=async()=>{ const d=await list(); if(d.ok) setItems(d.items) }
  React.useEffect(()=>{ refresh(); const t=setInterval(refresh,2000); return ()=>clearInterval(t)},[])
  return (<div className="p-4 text-white space-y-3">
    <ResourceMonitor/>
    <h1 className="text-lg font-semibold">Approvals</h1>
    <div className="grid md:grid-cols-2 xl:grid-cols-3 gap-3">
      {items.map(it=>(
        <div key={it.id} className="rounded border border-zinc-700/60 bg-zinc-900/50 p-3 space-y-1">
          <div className="text-sm font-medium">{it.kind||'action'}</div>
          <div className="text-xs opacity-70">{new Date(it.time).toLocaleString()}</div>
          <pre className="text-xs bg-black/40 p-2 rounded overflow-auto max-h-40">{JSON.stringify(it, null, 2)}</pre>
          <div className="flex gap-2">
            <button className="px-2 py-1 border rounded" onClick={()=>decide(it.id,true).then(refresh)}>Approve</button>
            <button className="px-2 py-1 border rounded" onClick={()=>decide(it.id,false).then(refresh)}>Deny</button>
          </div>
        </div>
      ))}
    </div>
  </div>)
}
