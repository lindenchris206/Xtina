
import React from 'react'
import ResourceMonitor from '../components/ResourceMonitor'
import '../styles/resmon.css'
export default function Jobs(){
  const [jobs,setJobs]=React.useState([])
  const add=()=> setJobs(j=>[{ id:'j-'+Date.now().toString(36), title:'New Job', steps:[{id:'s1',name:'plan',status:'queued'},{id:'s2',name:'runA',status:'queued'},{id:'s3',name:'runB',status:'queued'},{id:'s4',name:'judge',status:'queued'}]},...j])
  return (<div className="p-4 text-white space-y-3">
    <ResourceMonitor/>
    <h1 className="text-lg font-semibold">Jobs</h1>
    <button className="px-3 py-1 border rounded" onClick={add}>New Job</button>
    <div className="space-y-3">
      {jobs.map(job=>(
        <div key={job.id} className="rounded border border-zinc-700/60 bg-zinc-900/50 p-3">
          <div className="text-sm font-medium">{job.title}</div>
          <div className="mt-2 grid md:grid-cols-4 gap-2">
            {job.steps.map(st=> <div key={st.id} className="rounded border border-zinc-700/60 bg-black/40 p-2 text-xs"><div>{st.name}</div><div className="opacity-70">{st.status}</div></div>)}
          </div>
        </div>
      ))}
    </div>
  </div>)
}
