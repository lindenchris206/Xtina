
import React from 'react'
import ResourceMonitor from '../components/ResourceMonitor'
import '../styles/resmon.css'
import { encryptVault, decryptVault, newVault, genPassword } from '../lib/crypto/vault'
import { fsMkdir, fsWrite, fsRead } from '../lib/fsClient'
const VAULT_PATH='/secure/passwords.vault.json'
export default function PasswordManager(){
  const [unlocked,setUnlocked]=React.useState(false)
  const [master,setMaster]=React.useState('')
  const [vault,setVault]=React.useState(null)
  const [status,setStatus]=React.useState('')
  const [remember,setRemember]=React.useState(()=> localStorage.getItem('xtina:vault:remember')==='1')
  const lock=()=>{ setUnlocked(false); setVault(null) }
  const setRem=(v)=>{ setRemember(v); localStorage.setItem('xtina:vault:remember', v?'1':'0') }
  const load=async()=>{ try{ setStatus('Loading vault...'); const buf=await fsRead(VAULT_PATH); const blob=JSON.parse(new TextDecoder().decode(buf)); const data=await decryptVault(master, blob); setVault(data); setUnlocked(true); setStatus('Unlocked.') }catch(e){ setStatus('No vault or wrong password; creating new.'); setVault(newVault()); setUnlocked(true) } }
  const save=async()=>{ if(!vault) return; setStatus('Encrypting & saving...'); const blob=await encryptVault(master, vault); try{ await fsMkdir('/secure') }catch(e){} await fsWrite(VAULT_PATH, JSON.stringify(blob,null,2)); setStatus('Saved to '+VAULT_PATH) }
  const add=()=> setVault(v=> ({...v, entries:[...v.entries, { id:Date.now().toString(36), title:'New', url:'', username:'', password: genPassword(18), notes:'' }]}))
  const upd=(id,p)=> setVault(v=> ({...v, entries: v.entries.map(e=> e.id===id? {...e,...p}:e)}))
  const rm=(id)=> setVault(v=> ({...v, entries: v.entries.filter(e=> e.id!==id)}))
  React.useEffect(()=>{ if(remember && master && !unlocked){ load() } }, [remember])
  return (<div className="p-4 text-white space-y-4">
    <ResourceMonitor/>
    <h1 className="text-lg font-semibold">Password Manager</h1>
    {!unlocked ? (<div className="max-w-md rounded-xl p-3 border border-zinc-700/60 bg-zinc-900/60">
      <div className="text-sm opacity-80 mb-1">Enter master password</div>
      <input type="password" className="w-full rounded bg-black/40 border border-zinc-700/60 px-2 py-1" value={master} onChange={e=>setMaster(e.target.value)} />
      <div className="mt-2 flex items-center gap-2">
        <button className="px-3 py-1 rounded border border-zinc-700/60 bg-black/50" onClick={load}>Unlock / Create</button>
        <label className="text-xs opacity-80 flex items-center gap-1"><input type="checkbox" checked={remember} onChange={e=>setRem(e.target.checked)} /> remember master (browser only)</label>
      </div>
      <div className="text-xs opacity-70 mt-2">{status}</div>
      <div className="text-[11px] opacity-60 mt-2">Zero-knowledge: server stores only encrypted bytes. Lose the master = lose the vault.</div>
    </div>):(<>
      <div className="flex items-center gap-2">
        <button className="px-3 py-1 rounded border border-zinc-700/60 bg-black/50" onClick={save}>Save</button>
        <button className="px-3 py-1 rounded border border-zinc-700/60 bg-black/50" onClick={add}>Add</button>
        <button className="px-3 py-1 rounded border border-zinc-700/60 bg-black/50" onClick={lock}>Lock</button>
        <div className="text-xs opacity-70">{status}</div>
      </div>
      <div className="grid md:grid-cols-2 xl:grid-cols-3 gap-3">
        {vault.entries.map(e=> (
          <div key={e.id} className="rounded-lg border border-zinc-700/60 bg-zinc-900/50 p-3 space-y-2">
            <input className="w-full rounded bg-black/40 border border-zinc-700/60 px-2 py-1" value={e.title} onChange={ev=>upd(e.id,{title:ev.target.value})} placeholder="Title" />
            <input className="w-full rounded bg-black/40 border border-zinc-700/60 px-2 py-1" value={e.url} onChange={ev=>upd(e.id,{url:ev.target.value})} placeholder="URL" />
            <div className="grid grid-cols-2 gap-2">
              <input className="rounded bg-black/40 border border-zinc-700/60 px-2 py-1" value={e.username} onChange={ev=>upd(e.id,{username:ev.target.value})} placeholder="Username" />
              <div className="flex gap-2">
                <input className="flex-1 rounded bg-black/40 border border-zinc-700/60 px-2 py-1" value={e.password} onChange={ev=>upd(e.id,{password:ev.target.value})} placeholder="Password" />
                <button className="px-2 rounded border border-zinc-700/60 bg-black/50 text-xs" onClick={()=>upd(e.id,{password: genPassword(18)})}>Gen</button>
              </div>
            </div>
            <textarea rows={3} className="w-full rounded bg-black/40 border border-zinc-700/60 px-2 py-1" value={e.notes} onChange={ev=>upd(e.id,{notes:ev.target.value})} placeholder="Notes (2FA, recovery)"></textarea>
            <div className="flex justify-between text-xs opacity-70">
              <a className="underline" href={e.url || '#'} target="_blank" rel="noreferrer">open</a>
              <button className="underline" onClick={()=>rm(e.id)}>remove</button>
            </div>
          </div>
        ))}
      </div>
    </>)}
  </div>)
}
