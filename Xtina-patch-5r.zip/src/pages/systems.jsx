
import React from 'react'
import '../styles/resmon.css'
function useStats(){
  const [h,setH]=React.useState([])
  React.useEffect(()=>{ let t; const tick=async()=>{ const r=await fetch('/api/sys/stats'); const d=await r.json(); if(d.ok){ setH(x=>[...x.slice(-299), {t:Date.now(), cpu:d.cpu.percent, ram:d.memory.percent, gpu:d.gpu?d.gpu.percent:null}]) } t=setTimeout(tick,2000) }; tick(); return ()=>clearTimeout(t) },[])
  return h
}
function Chart({data, keyy, title}){
  const ref=React.useRef(null)
  React.useEffect(()=>{ const ctx=ref.current.getContext('2d'); const w=ref.current.width, h=ref.current.height; ctx.clearRect(0,0,w,h); ctx.fillStyle='#0b1220'; ctx.fillRect(0,0,w,h); ctx.strokeStyle='#6ee7ff'; ctx.beginPath(); const arr=data.map(d=>d[keyy]==null?0:d[keyy]); const n=arr.length; for(let i=0;i<n;i++){ const x=i*(w/Math.max(1,n-1)); const y=h - (Math.max(0,Math.min(100,arr[i]))/100)*h; if(i===0) ctx.moveTo(x,y); else ctx.lineTo(x,y) } ctx.stroke(); ctx.fillStyle='#e5e7eb'; ctx.fillText(title, 8, 12) }, [data, keyy])
  return <canvas ref={ref} width={420} height={140} className="rounded border border-zinc-700/60" />
}
export default function Systems(){
  const h=useStats()
  return (<div className="p-4 text-white space-y-3">
    <h1 className="text-lg font-semibold">Systems</h1>
    <div className="grid md:grid-cols-2 xl:grid-cols-3 gap-3">
      <Chart data={h} keyy="cpu" title="CPU %" />
      <Chart data={h} keyy="ram" title="RAM %" />
      <Chart data={h} keyy="gpu" title="GPU %" />
    </div>
  </div>)
}
