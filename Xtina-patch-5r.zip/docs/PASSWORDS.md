
# Password Manager — Zero-knowledge
Client-side AES-GCM (PBKDF2-SHA256). Server stores only ciphertext at `/secure/passwords.vault.json`.
