\n\n### Patch 5o — Resource Monitor + Agents upgrade\n- Floating Resource Monitor (CPU/GPU/RAM).\n- Server endpoint GET /api/sys/stats.\n- Agents: Archivist & Team Lead upgraded (bigger memory, 7 secondaries).\n

### Patch 5p — One-file installs + Advanced magnets + Debate/Leader upgrades
- **One-file installers**: `install.sh` (Unix) and `install.ps1` (Windows). `install.sh --service` adds a systemd service.
- **Modular**: 16-point compass magnets, sibling-to-sibling snapping, link/unlink for collaboration edges, crowd-aware hex silhouette.
- **Debate**: Added protocol scaffold (devil's advocate, steelman, cross-exam), rubric scorer, and weighted blending.
- **Leader**: Fanout the same task to two models, auto-score, and blend; see `/leader-demo`.


### Patch 5r — Passwords, Approvals/Audit, Jobs, Systems
- **/passwords**: zero-knowledge password vault (AES-GCM, PBKDF2), FS-backed.
- **/approvals** + **/api/approvals**: gated actions and JSONL audit chain.
- **/jobs**: planner/executor skeleton with step slots (fanout/judge hooks).
- **/systems**: rolling CPU/GPU/RAM charts.
- **Dockerfile** + **docker-compose.yml** for FS API.
