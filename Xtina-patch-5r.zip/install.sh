#!/usr/bin/env bash
set -euo pipefail
APP_NAME="xtina"
APP_DIR="$(pwd)"
SERVER_PKG="$APP_DIR/package.server.json"
PKG="$APP_DIR/package.json"

echo "==> Xtina single-file installer"
if ! command -v node >/dev/null 2>&1; then
  echo "NodeJS not found. Please install Node 18+ or run: curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash - && sudo apt-get install -y nodejs"
  exit 1
fi

# Prepare package.json for server
if [ -f "$SERVER_PKG" ]; then
  cp "$SERVER_PKG" "$PKG"
fi

echo "==> Installing dependencies..."
npm i --silent

export XTINA_ROOT="${XTINA_ROOT:-$APP_DIR/workspace}"
mkdir -p "$XTINA_ROOT"

if [ "${1:-}" = "--service" ]; then
  echo "==> Installing systemd service"
  SVC=/etc/systemd/system/${APP_NAME}-fsapi.service
  sudo bash -c "cat > $SVC" <<EOF
[Unit]
Description=Xtina FS API
After=network.target

[Service]
Type=simple
Environment=XTINA_ROOT=${XTINA_ROOT}
WorkingDirectory=${APP_DIR}
ExecStart=/usr/bin/node --enable-source-maps node_modules/.bin/tsx server/index.ts
Restart=on-failure
User=${USER}
Group=${USER}

[Install]
WantedBy=multi-user.target
EOF
  sudo systemctl daemon-reload
  sudo systemctl enable --now ${APP_NAME}-fsapi
  systemctl status ${APP_NAME}-fsapi --no-pager
  echo "Service installed. API at http://localhost:8788"
else
  echo "==> Starting dev server (Ctrl+C to stop)"
  npm run dev
fi
