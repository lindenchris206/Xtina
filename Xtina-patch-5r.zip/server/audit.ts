
import fs from 'fs'; import fsp from 'fs/promises'; import path from 'path'
const ROOT = process.env.XTINA_ROOT || path.resolve(process.cwd(), 'workspace')
const LOG = path.join(ROOT, 'audit', 'audit.jsonl')
await fsp.mkdir(path.dirname(LOG), { recursive: true })
let lastHash = ''
export async function log(entry:any){ // append-jsonl with hash-chain
  const rec = { time: Date.now(), ...entry, prev: lastHash }
  const str = JSON.stringify(rec)
  // simple hash (not cryptographic): DJB2
  let h=5381; for(let i=0;i<str.length;i++){ h=((h<<5)+h)+str.charCodeAt(i) } lastHash = (h>>>0).toString(16)
  await fsp.appendFile(LOG, str+'\n')
  return { ok:true, hash:lastHash }
}
export async function list(){ try{ const data = await fsp.readFile(LOG,'utf8'); return data.trim().split('\n').map(l=> JSON.parse(l)) }catch{ return [] } }
