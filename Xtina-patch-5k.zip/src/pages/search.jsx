import React from 'react'
import {GlobalSearchBar} from './contrib/GlobalSearchBar'
export default function Page(){ return <div className="p-2"><GlobalSearchBar /></div> }
