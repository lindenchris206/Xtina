/**
 * @author cel
 * @file components/InstructionPanel.tsx
 * @description A dismissible panel for showing contextual instructions.
 */
import React, { useState } from 'react';
import { XIcon, IntelIcon } from './icons';

interface InstructionPanelProps {
  title: string;
  children: React.ReactNode;
  storageKey: string;
}

export const InstructionPanel: React.FC<InstructionPanelProps> = ({ title, children, storageKey }) => {
  const [isVisible, setIsVisible] = useState(!localStorage.getItem(storageKey));

  const handleDismiss = () => {
    try {
        localStorage.setItem(storageKey, 'dismissed');
        setIsVisible(false);
    } catch (error) {
        console.warn("Could not save dismissal state to localStorage:", error);
        setIsVisible(false);
    }
  };

  if (!isVisible) {
    return null;
  }

  return (
    <div className="bg-gray-800/60 border border-indigo-500/30 rounded-lg p-3 text-sm text-gray-300 mb-4 relative">
      <button onClick={handleDismiss} className="absolute top-2 right-2 p-1 text-gray-500 hover:text-white">
        <XIcon />
      </button>
      <h4 className="font-bold text-indigo-300 flex items-center gap-2 mb-1">
        <span className="w-5 h-5"><IntelIcon /></span>
        {title}
      </h4>
      {children}
    </div>
  );
};
