/**
 * @author cel
 * @file components/TimelineView.tsx
 * @description Defines the main content for the Mission Timeline application view.
 */
import React from 'react';
import { useMission } from '../context/MissionContext';
import { MissionTimeline } from './MissionTimeline';

const TimelineView: React.FC = () => {
    const { appState } = useMission();
    return (
        <div className="h-full">
            <MissionTimeline plan={appState.plan} />
        </div>
    );
};

export default TimelineView;
