/**
 * @author cel
 * @file components/AutomationPlanView.tsx
 * @description Renders a view of the web automation plan.
 */
import React from 'react';
import type { AutomationStep } from '../types';
import { BrowserIcon } from './icons';

interface AutomationPlanViewProps {
    plan: AutomationStep[];
}

const getActionColor = (action: string) => {
    switch(action) {
        case 'navigate': return 'bg-blue-500/50 text-blue-300';
        case 'type': return 'bg-green-500/50 text-green-300';
        case 'click': return 'bg-yellow-500/50 text-yellow-300';
        case 'submit': return 'bg-purple-500/50 text-purple-300';
        default: return 'bg-gray-500/50 text-gray-300';
    }
}

export const AutomationPlanView: React.FC<AutomationPlanViewProps> = ({ plan }) => {
    return (
        <div className="border-l-2 border-pink-500/30 pl-4 my-4 space-y-2">
            <h4 className="text-sm font-bold text-pink-400 flex items-center gap-2">
                <BrowserIcon /> Automation Sequence:
            </h4>
            {plan.map((step, index) => (
                <div key={index} className="flex items-start gap-3 text-xs p-2 rounded-md bg-gray-900/50">
                    <div className="flex-shrink-0 w-5 h-5 flex items-center justify-center font-bold text-pink-300 mt-0.5">
                        {index + 1}.
                    </div>
                    <div className="flex-grow">
                        <div className="flex items-center gap-2">
                             <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${getActionColor(step.action)}`}>
                                {step.action.toUpperCase()}
                            </span>
                            {step.target && <code className="text-cyan-300">{step.target}</code>}
                            {step.value && <span className="text-gray-400">with value "{step.value}"</span>}
                            {step.valueFromProfile && <span className="text-gray-400">with value from profile: <code className="text-cyan-300">{step.valueFromProfile}</code></span>}
                        </div>
                         <p className="text-gray-400 italic mt-1 text-[11px]">"{step.thought}"</p>
                    </div>
                </div>
            ))}
        </div>
    );
};