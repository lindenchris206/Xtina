import React from 'react';

export const DatabaseExplorer: React.FC = () => {
    return (
        <div className="p-4 glassmorphism rounded-xl h-full flex items-center justify-center">
            <p className="text-gray-500">Database Explorer Interface</p>
        </div>
    );
};
