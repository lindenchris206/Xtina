/**
 * @author cel
 * @file components/CommsView.tsx
 * @description Defines the main content for the Crew Communications application view.
 */
import React from 'react';
import { useMission } from '../context/MissionContext';
import { CrewChat } from './CrewChat';

const CommsView: React.FC = () => {
    const { activeCrew } = useMission();
    return (
        <div className="h-full">
            <CrewChat activeCrew={activeCrew} />
        </div>
    );
};

export default CommsView;
