import React from 'react'
import * as Av from './contrib/avatars'
const Comp = (Av.default || Av.Avatars || Av.AvatarGallery || Av.AvatarsView || Av.AvatarGrid || (()=> <div style={padding:12}>No default export found in avatars.tsx. Export one of: default, Avatars, AvatarGallery.</div>))
export default function Page(){ return <div className="p-2"><Comp /></div> }
