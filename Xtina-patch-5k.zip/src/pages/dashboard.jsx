import React from 'react'
import DashboardView from './contrib/DashboardView'
export default function Page(){
  return <div className="p-2"><DashboardView /></div>
}
