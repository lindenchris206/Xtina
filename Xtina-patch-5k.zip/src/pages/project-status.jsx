import React from 'react'
import {ProjectStatusDisplay} from './contrib/ProjectStatusDisplay'
export default function Page(){ return <div className="p-2"><ProjectStatusDisplay /></div> }
