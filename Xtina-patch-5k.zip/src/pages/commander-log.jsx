import React from 'react'
import CommanderLog from './contrib/CommanderLog'
export default function Page(){
  return <div className="p-2"><CommanderLog /></div>
}
