import React from 'react'
export default function Index(){
  const links = [
    ['/modular','Modular Canvas'],
    ['/workbench','Workbench'],
    ['/files','Files'],
    ['/knowledge','Knowledge Bases'],
    ['/agents','Agents'],
    ['/debate','Debate'],
    ['/login','Login'],
    ['/dashboard','Dashboard'],
    ['/database','Database Explorer'],
    ['/email','Email Client'],
    ['/terminal','Terminal'],
    ['/crew','Crew Chat'],
    ['/timeline','Timeline'],
    ['/intel','Intel'],
    ['/capabilities','Capabilities'],
    ['/mission-plan','Mission Plan'],
    ['/mission-vitals','Mission Vitals'],
    ['/mission-debrief','Mission Debrief'],
    ['/vault','Vault'],
    ['/automation-plan','Automation Plan'],
    ['/commander-log','Commander Log']
  ]
  return (
    <div className="p-6">
      <h1 className="text-xl font-semibold">Xtina — Pages</h1>
      <ul className="mt-3 space-y-2">
        {links.map(([href,label])=>(
          <li key={href}><a className="underline" href={href}>{label}</a></li>
        ))}
      
        <li key="/project-status"><a className="underline" href="/project-status">Project Status Display</a></li>

        <li key="/crew-card"><a className="underline" href="/crew-card">Crew Member Card</a></li>

        <li key="/avatars"><a className="underline" href="/avatars">Avatars</a></li>

        <li key="/search"><a className="underline" href="/search">Global Search Bar</a></li>
</ul>
    </div>
  )
}
