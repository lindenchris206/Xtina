import React from 'react'
import DatabaseExplorer from './contrib/DatabaseExplorer'
export default function Page(){
  return <div className="p-2"><DatabaseExplorer /></div>
}
