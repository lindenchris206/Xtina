import React from 'react'
import VaultView from './contrib/VaultView'
export default function Page(){
  return <div className="p-2"><VaultView /></div>
}
