import React from 'react'
import {CrewMemberCard} from './contrib/CrewMemberCard'
export default function Page(){ return <div className="p-2"><CrewMemberCard /></div> }
