import React from 'react'
import CrewChat from './contrib/CrewChat'
export default function Page(){
  return <div className="p-2"><CrewChat /></div>
}
