import React from 'react'
import LoginScreen from './contrib/LoginScreen'
export default function Page(){
  return <div className="p-2"><LoginScreen /></div>
}
