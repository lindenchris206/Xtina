import React from 'react'
import MissionPlanView from './contrib/MissionPlanView'
export default function Page(){
  return <div className="p-2"><MissionPlanView /></div>
}
