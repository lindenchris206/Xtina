import React from 'react'
import { newThreadId, saveThread, loadThread, listThreads, exportThread, saveThreadFs, exportAllThreadsZip, downloadFsFile } from '../lib/chatStore'
import React from 'react'
export default function Workbench(){ return <div className="p-6">Workbench placeholder</div> }
