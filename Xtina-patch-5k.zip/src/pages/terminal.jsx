import React from 'react'
import Terminal from './contrib/Terminal'
export default function Page(){
  return <div className="p-2"><Terminal /></div>
}
