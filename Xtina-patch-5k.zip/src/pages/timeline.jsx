import React from 'react'
import TimelineView from './contrib/TimelineView'
export default function Page(){
  return <div className="p-2"><TimelineView /></div>
}
