import React from 'react'
import IntelView from './contrib/IntelView'
export default function Page(){
  return <div className="p-2"><IntelView /></div>
}
