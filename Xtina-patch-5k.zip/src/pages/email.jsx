import React from 'react'
import EmailClientView from './contrib/EmailClientView'
export default function Page(){
  return <div className="p-2"><EmailClientView /></div>
}
