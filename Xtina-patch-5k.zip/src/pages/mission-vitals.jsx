import React from 'react'
import MissionVitals from './contrib/MissionVitals'
export default function Page(){
  return <div className="p-2"><MissionVitals /></div>
}
