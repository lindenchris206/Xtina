import React from 'react'
import CapabilitiesView from './contrib/CapabilitiesView'
export default function Page(){
  return <div className="p-2"><CapabilitiesView /></div>
}
