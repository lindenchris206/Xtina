import React from 'react'
import MissionDebriefView from './contrib/MissionDebriefView'
export default function Page(){
  return <div className="p-2"><MissionDebriefView /></div>
}
