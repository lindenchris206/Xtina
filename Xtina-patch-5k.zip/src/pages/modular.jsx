
import React from 'react'

const KEY='xtina:modular:layout'
const SILVER = 'bg-[linear-gradient(145deg,_#dfe3ea_0%,_#c9ced6_38%,_#b8bec8_60%,_#e9edf2_100%)]'
const GLOW_BLUE = 'shadow-[0_0_22px_4px_rgba(56,189,248,0.45),_0_0_70px_16px_rgba(56,189,248,0.25)]'
const GLOW_PINK = 'shadow-[0_0_20px_4px_rgba(244,114,182,0.5),_0_0_64px_14px_rgba(192,132,252,0.3)]'
const HEX = '[clip-path:polygon(25%_0%,_75%_0%,_100%_50%,_75%_100%,_25%_100%,_0%_50%)]'

const pulseStyle = `
@keyframes pulseGlow {
  0% { box-shadow: 0 0 16px 3px rgba(244,114,182,0.45), 0 0 48px 10px rgba(192,132,252,0.22); }
  50% { box-shadow: 0 0 24px 5px rgba(244,114,182,0.85), 0 0 72px 18px rgba(192,132,252,0.45); }
  100% { box-shadow: 0 0 16px 3px rgba(244,114,182,0.45), 0 0 48px 10px rgba(192,132,252,0.22); }
}
.pulse { animation: pulseGlow 1.2s ease-in-out infinite; }
.bright { box-shadow: 0 0 26px 6px rgba(244,114,182,0.95), 0 0 90px 26px rgba(192,132,252,0.65); }
`
function useSize(){
  const [s,setS]=React.useState({w:window.innerWidth,h:window.innerHeight})
  React.useEffect(()=>{ const on=()=>setS({w:window.innerWidth,h:window.innerHeight}); window.addEventListener('resize',on); return()=>window.removeEventListener('resize',on)},[])
  return s
}
function ring(count, center, r){
  const out=[], start=-Math.PI/2
  for(let i=0;i<count;i++){ const t=start + i*(2*Math.PI/count); out.push({x:center.x + r*Math.cos(t), y:center.y + r*Math.sin(t)}) }
  return out
}
function dist(a,b){ const dx=a.x-b.x, dy=a.y-b.y; return Math.hypot(dx,dy) }

export default function ModularPage(){
  const {w,h}=useSize(); const center={x:w/2, y:h/2 - 40}
  const [nodes,setNodes]=React.useState(()=>{ try{ return JSON.parse(localStorage.getItem(KEY)) || [] }catch{ return [] } })
  React.useEffect(()=>{ localStorage.setItem(KEY, JSON.stringify(nodes)) },[nodes])
  const baseSize=260, childSize=150

  const docks = React.useMemo(()=>{
    const r = baseSize/2 + childSize/2 + 14
    const s = 40 // spread for diagonals
    return [
      {id:'N', x:center.x, y:center.y - r},
      {id:'NE', x:center.x + r*0.707, y:center.y - r*0.707},
      {id:'E', x:center.x + r, y:center.y},
      {id:'SE', x:center.x + r*0.707, y:center.y + r*0.707},
      {id:'S', x:center.x, y:center.y + r},
      {id:'SW', x:center.x - r*0.707, y:center.y + r*0.707},
      {id:'W', x:center.x - r, y:center.y},
      {id:'NW', x:center.x - r*0.707, y:center.y - r*0.707},
    ]
  },[center.x,center.y])

  const [hoverDock,setHoverDock] = React.useState(null)

  React.useEffect(()=>{
    if(nodes.length>4){
      const coords=ring(nodes.length, center, Math.min(w,h)/3.0)
      setNodes(prev=> prev.map((n,i)=>({...n,x:coords[i].x, y:coords[i].y, hex:true})))
    } else {
      setNodes(prev=> prev.map(n=>({...n, hex:false})))
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  },[nodes.length, w, h])

  const addNode = (title)=>{
    const angle = (nodes.length%4)*Math.PI/2; const r = baseSize*0.9 + 40
    const pos = { x: center.x + r*Math.cos(angle), y: center.y + r*Math.sin(angle) }
    setNodes(ns=> [...ns, { id: Date.now().toString(36), title, x: pos.x, y: pos.y }])
  }
  const removeNode = (id)=> setNodes(ns=> ns.filter(n=> n.id!==id))

  const drag = React.useRef({ id:null, dx:0, dy:0 })
  const onDown=(e,id)=>{
    const n = nodes.find(n=>n.id===id); if(!n) return
    drag.current={ id, dx:e.clientX - n.x, dy:e.clientY - n.y }
    window.addEventListener('mousemove', onMove); window.addEventListener('mouseup', onUp)
  }
  const onMove=(e)=>{
    const d=drag.current; if(!d.id) return
    const nx = e.clientX - d.dx, ny = e.clientY - d.dy
    let closest=null, min=1e9
    for(const dk of docks){
      const m = dist({x:nx,y:ny}, dk)
      if(m < min){ min = m; closest = dk }
    }
    const SNAP=90
    if(min < SNAP){ setHoverDock(closest.id); setNodes(ns=> ns.map(n=> n.id===d.id ? {...n, x: closest.x, y: closest.y, dock: closest.id, docked:true } : n)) }
    else { setHoverDock(null); setNodes(ns=> ns.map(n=> n.id===d.id ? {...n, x:nx, y:ny, dock:null, docked:false } : n)) }
  }
  const onUp=()=>{ drag.current={id:null,dx:0,dy:0}; setHoverDock(null); window.removeEventListener('mousemove', onMove); window.removeEventListener('mouseup', onUp) }

  const lines = nodes.map(n=>({ x1:center.x, y1:center.y, x2:n.x, y2:n.y }))
  const palette = ['Research','Build','Review','Deploy','Docs','Analyze','Design','Finance']

  return (
    <div className="h-[calc(100vh-64px)] relative overflow-hidden bg-gradient-to-b from-zinc-900 via-black to-zinc-950 text-white">
      <style>{pulseStyle}</style>

      {/* palette */}
      <div className="absolute left-2 top-2 bottom-2 w-48 rounded-2xl border border-zinc-700/60 bg-zinc-900/60 p-3 backdrop-blur">
        <div className="text-sm opacity-80">Blocks</div>
        <div className="mt-2 grid grid-cols-2 gap-2">
          {palette.map(p=> (
            <button key={p} className={`text-xs ${SILVER} ${GLOW_PINK} rounded-xl px-2 py-2 text-zinc-800 hover:opacity-90`}
              onClick={()=> addNode(p)}>{p}</button>
          ))}
        </div>
        <div className="mt-4 text-xs opacity-60">
          Drag blocks near the base to see <span className="text-pink-300">magnet pulses</span>. When docked, glow gets brighter.
        </div>
      </div>

      {/* SVG lines */}
      <svg className="absolute inset-0 pointer-events-none" width={w} height={h}>
        <defs>
          <linearGradient id="grad" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="#38bdf8" stopOpacity="0.6"/>
            <stop offset="100%" stopColor="#f472b6" stopOpacity="0.6"/>
          </linearGradient>
        </defs>
        {lines.map((l,i)=> (
          <line key={i} x1={l.x1} y1={l.y1} x2={l.x2} y2={l.y2} stroke="url(#grad)" strokeWidth="2" />
        ))}
      </svg>

      {/* base block */}
      <div className={`absolute ${SILVER} ${GLOW_BLUE} rounded-3xl text-zinc-800`} style={{
        width: baseSize, height: baseSize, left: center.x - baseSize/2, top: center.y - baseSize/2 }}>
        <div className="h-full w-full flex flex-col items-center justify-center select-none">
          <div className="text-xl font-semibold">BASE</div>
          <div className="text-xs opacity-70">Silver core • Blue glow</div>
          <div className="mt-2 text-[10px] opacity-60">{nodes.length} linked</div>
        </div>
        {/* magnet spots */}
        {docks.map(dk=>(
          <div key={dk.id}
            className={`absolute w-3 h-3 rounded-full ${hoverDock===dk.id? 'bg-pink-300 pulse':'bg-pink-800/40'}`}
            style={{ left: dk.x - (center.x) + baseSize/2 - 6, top: dk.y - (center.y) + baseSize/2 - 6 }}/>
        ))}
      </div>

      {/* child blocks */}
      {nodes.map(n=> (
        <div key={n.id}
          className={`absolute ${SILVER} ${GLOW_PINK} ${n.hex?HEX:''} ${n.docked?'bright':''} rounded-2xl text-zinc-800 cursor-move`}
          style={{ width: childSize, height: childSize, left: n.x - childSize/2, top: n.y - childSize/2 }}
          onMouseDown={(e)=> onDown(e, n.id)}
        >
          <div className="h-full w-full flex flex-col items-center justify-center select-none">
            <div className="font-semibold">{n.title}</div>
            <div className="text-[11px] opacity-60">{n.dock?('docked @ '+n.dock):'drag to position'}</div>
            <button className="mt-2 text-[11px] underline" onClick={(e)=>{ e.stopPropagation(); removeNode(n.id) }}>remove</button>
          </div>
        </div>
      ))}

      {/* quick controls */}
      <div className="absolute right-4 top-4 flex gap-2">
        <button className="px-3 py-2 rounded-lg border border-zinc-700/60 bg-black/50" onClick={()=> setNodes([])}>Clear</button>
        <button className="px-3 py-2 rounded-lg border border-zinc-700/60 bg-black/50" onClick={()=> localStorage.setItem(KEY, JSON.stringify(nodes))}>Save</button>
      </div>
    </div>
  )
}
