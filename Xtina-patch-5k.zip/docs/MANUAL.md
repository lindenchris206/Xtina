

## Patch 5k — Chat → Files (Autosave + Export ZIP)
- **Chats now mirror to disk** under `/chats/<threadId>.json` via the FS API.
- New toolbar buttons in `/workbench`:
  - **Save to Files** (write current thread to `/chats`)
  - **Export All (ZIP)** (zips all chats under `/chats` and downloads the archive)
  - **Autosave to Files** toggle (persisted)
- This keeps long memory both in-browser and on disk for backups and sharing.

_Generated: 2025-10-22 22:41:02_
