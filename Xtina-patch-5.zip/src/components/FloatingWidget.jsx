/**
 * FloatingWidget.jsx
 * Draggable, pinnable assistant widget. Voice is muted by default.
 */
import React from 'react';

export default function FloatingWidget(){
  const [open, setOpen] = React.useState(false);
  const [pinned, setPinned] = React.useState(false);
  const ref = React.useRef(null);
  const pos = React.useRef({ x: 24, y: 24 });
  const dragging = React.useRef(false);

  React.useEffect(()=>{
    const el = ref.current;
    if(!el) return;
    const onMouseDown = (e)=>{ dragging.current = true; el.dataset.dragging='1'; };
    const onMouseUp = ()=>{ dragging.current = false; el.dataset.dragging='0'; };
    const onMouseMove = (e)=>{
      if(!dragging.current || pinned) return;
      pos.current.x += e.movementX;
      pos.current.y += e.movementY;
      el.style.left = pos.current.x + 'px';
      el.style.top = pos.current.y + 'px';
    };
    window.addEventListener('mousedown', onMouseDown);
    window.addEventListener('mouseup', onMouseUp);
    window.addEventListener('mousemove', onMouseMove);
    return ()=>{
      window.removeEventListener('mousedown', onMouseDown);
      window.removeEventListener('mouseup', onMouseUp);
      window.removeEventListener('mousemove', onMouseMove);
    };
  }, [pinned]);

  return (
    <>
      <button
        className="fixed bottom-6 right-6 rounded-full shadow-lg px-4 py-3"
        onClick={()=>setOpen(!open)}
        aria-expanded={open}
        aria-controls="xtina-floating-panel"
      >
        ✨
      </button>

      {open && (
        <div
          id="xtina-floating-panel"
          ref={ref}
          style={{ left: pos.current.x, top: pos.current.y }}
          className="fixed z-50 bg-white/90 dark:bg-zinc-900/90 backdrop-blur p-4 rounded-2xl shadow-xl w-[360px]"
        >
          <div className="flex items-center justify-between gap-2">
            <strong>Quick Assist</strong>
            <div className="flex items-center gap-2">
              <button onClick={()=>setPinned(!pinned)} aria-pressed={pinned} title="Pin/unpin">{pinned ? '📌' : '📍'}</button>
              <button onClick={()=>setOpen(false)} aria-label="Close">✖</button>
            </div>
          </div>
          <div className="mt-3 space-y-2">
            <p className="text-sm opacity-80">Drop files or links here to create a knowledge bundle.</p>
            <div className="border border-dashed rounded-lg p-3 text-sm" onDragOver={(e)=>e.preventDefault()} onDrop={(e)=>{
              e.preventDefault();
              // TODO: wire up to bundle creation
              alert('Bundle intake received. (Wire to backend)');
            }}>Drop Zone</div>

            <div className="flex gap-2 text-sm">
              <button className="px-3 py-2 rounded-lg border">Screenshot</button>
              <button className="px-3 py-2 rounded-lg border">New Note</button>
              <button className="px-3 py-2 rounded-lg border">Summarize</button>
            </div>

            <div className="pt-2 border-t mt-2">
              <label className="flex items-center gap-2 text-sm">
                <input type="checkbox" defaultChecked={false} aria-label="Voice output" />
                Voice (muted by default)
              </label>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
