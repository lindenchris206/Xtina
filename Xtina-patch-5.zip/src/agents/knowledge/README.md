# Knowledge Bundles
Place bundle manifests and payloads here. A bundle groups docs, URLs, and tags.

- `sample-bundle.manifest.json` is an example starter.
- Use tags to match bundles to agent specialties.
- Keep large files outside the repository when possible.
