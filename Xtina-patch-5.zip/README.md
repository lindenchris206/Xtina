# Xtina

## Patch 5 Additions
- FloatingWidget (src/components/FloatingWidget.jsx)
- AccessibilityControls (src/components/AccessibilityControls.jsx)
- AgentRegistry with specialties (src/agents/AgentRegistry.ts)
- Knowledge bundles scaffold (src/agents/knowledge/)
- Key Manager skeleton (src/config/keyManager/RotatingKeyManager.ts)
- Docs: PAGE_TREE.md, MANUAL.md

> Voice is muted by default; enable via Settings.
