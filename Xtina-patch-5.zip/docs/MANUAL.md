# Xtina Manual (Patch 5)

## 1. Overview
Xtina is a modular, multi-agent workspace. Renee acts as the team lead/orchestrator.
Agents can have primary and secondary specialties. Knowledge comes from user-provided bundles and optional scraping tasks.

## 2. Accessibility
- Text-size toggle in the header (A-/A+)
- Zoom controls in Settings (Zoom -, Reset, Zoom +)
- Voice is **muted by default**; enable in Settings if needed.

## 3. Floating Widget
- Click the bubble to open.
- Drag to dock left/right; pin to keep on top.
- Drop files/links to create ad-hoc knowledge bundles.

## 4. Knowledge Bundles
- Use **Knowledge → Drop Zone** to add files or URLs.
- Bundles include a manifest describing purpose, tags, and preferred agent specialties.
- Example manifest added at `src/agents/knowledge/sample-bundle.manifest.json`.

## 5. Connections & Key Rotation
- Add API keys in **Connections → API Key Manager**.
- Keys are encrypted at rest. Rotation tasks can be scheduled.
- Audit logs live at `data/logs/key-ops.log` (create the folder if it doesn't exist).

## 6. Engines & Agents
- Each agent can target a different engine (configurable).
- Renee delegates tasks to other agents based on specialties and bundle tags.

## 7. Web Studio
- Project-oriented workspace. File tree, live preview, and (optional) deploy.
- Connects with the browser module for scraping and bundle creation.

## 8. Troubleshooting
- If the app fails to start, check `.env` for required keys.
- Ensure Node version >= 18 if using the web UI.
- For rotation errors, check `data/logs/key-ops.log`.

_This draft ships with Patch 5 and will be iterated._