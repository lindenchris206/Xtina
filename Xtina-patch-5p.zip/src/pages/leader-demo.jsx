import React from 'react'
import { fanoutAndJudge } from '../lib/leader'
import ResourceMonitor from '../components/ResourceMonitor'
import '../styles/resmon.css'

async function mockRunModel(name, prompt){
  // placeholder outputs to show the flow
  if(name.includes('A')) return { text: `(${name}) suggests a quick approach for: ${prompt}`, steps:['step1','step2'] }
  return { text: `(${name}) drafts a safer but slower plan for: ${prompt}`, cites:['bundle:Docs:X'] }
}

export default function LeaderDemo(){
  const [q,setQ]=React.useState('Migrate database with near-zero downtime')
  const [out,setOut]=React.useState(null)

  const go = async ()=>{
    const res = await fanoutAndJudge({ prompt: q, models: ['Model-A','Model-B'], runModel: mockRunModel })
    setOut(res)
  }

  return (
    <div className="p-4 text-white space-y-3">
      <ResourceMonitor/>
      <h1 className="text-lg font-semibold">Leader Fanout Demo</h1>
      <div className="flex gap-2">
        <input className="flex-1 rounded bg-zinc-900/70 border border-zinc-700/60 px-2 py-1" value={q} onChange={e=>setQ(e.target.value)} />
        <button className="px-3 py-1 rounded border border-zinc-700/60 bg-black/50" onClick={go}>Run</button>
      </div>
      {out && (
        <div className="space-y-2">
          <div className="text-sm opacity-70">Proposals (scored):</div>
          {out.proposals.map(p=> (
            <div key={p.id} className="rounded border border-zinc-700/60 p-2 bg-zinc-900/40">
              <div className="text-xs">{p.author} — {(p.s.final*100).toFixed(1)}%</div>
              <div className="text-sm whitespace-pre-wrap">{p.text}</div>
            </div>
          ))}
          <div className="text-sm opacity-70">Blended summary:</div>
          <div className="rounded border border-zinc-700/60 p-2 bg-zinc-900/40 whitespace-pre-wrap">{out.blended.summary}</div>
        </div>
      )}
    </div>
  )
}
