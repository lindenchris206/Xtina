import React from 'react'
import { Rubric, scoreProposal, blend, Protocol } from '../lib/debateEngine'
import ResourceMonitor from '../components/ResourceMonitor'
import '../styles/resmon.css'

function Stage({title,children}){
  return <div className="rounded-xl border border-zinc-700/60 bg-black/40 p-3"><div className="text-sm opacity-70 mb-2">{title}</div>{children}</div>
}

export default function DebateRoom(){
  const [topic,setTopic]=React.useState('Should we use approach A or B?')
  const [proposals,setProposals]=React.useState([
    { id:'A', author:'Agent Alpha', text:'Approach A because it is simpler and faster.', cites:['bundle:Docs:A1'] },
    { id:'B', author:'Agent Beta', text:'Approach B because it scales better and is safer.', cites:['bundle:Docs:B1'] },
  ])
  const [blendOut,setBlendOut]=React.useState(null)

  const scored = proposals.map(p=> ({ ...p, s: scoreProposal(p) }))

  return (
    <div className="p-4 space-y-4 text-white">
      <ResourceMonitor/>
      <h1 className="text-lg font-semibold">Deliberation Room</h1>
      <Stage title="Brief">
        <input className="w-full rounded bg-zinc-900/70 border border-zinc-700/60 px-2 py-1" value={topic} onChange={e=>setTopic(e.target.value)} />
      </Stage>

      <Stage title="Proposals">
        <div className="grid md:grid-cols-2 gap-3">
          {scored.map(p=> (
            <div key={p.id} className="rounded-lg border border-zinc-700/60 p-3 bg-zinc-900/40">
              <div className="text-sm font-medium">{p.author}</div>
              <div className="text-xs opacity-70">Score {(p.s.final*100).toFixed(1)}%</div>
              <div className="mt-2 text-sm whitespace-pre-wrap">{p.text}</div>
              {p.cites?.length>0 && <div className="mt-2 text-xs opacity-70">Cites: {p.cites.join(', ')}</div>}
            </div>
          ))}
        </div>
      </Stage>

      <Stage title="Devil's advocate & Steelman (simulated)">
        <div className="text-xs opacity-70">These stages challenge then strengthen each proposal. Hook real models via orchestrator later.</div>
      </Stage>

      <Stage title="Blend">
        <button className="px-3 py-2 rounded border border-zinc-700/60 bg-black/50" onClick={()=> setBlendOut(blend(proposals))}>
          Compute Blend
        </button>
        {blendOut && (
          <div className="mt-2 text-sm whitespace-pre-wrap">{blendOut.summary}</div>
        )}
      </Stage>
    </div>
  )
}
